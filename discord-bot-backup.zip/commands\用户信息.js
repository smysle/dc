const { SlashCommandBuilder } = require('@discordjs/builders');
const { User } = require('../models');
const config = require('../config');
const moment = require('moment');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('用户信息')
    .setDescription('查看用户信息')
    .addUserOption(option => 
      option.setName('目标用户')
        .setDescription('要查看的Discord用户')
        .setRequired(true)),
    
  async execute(interaction) {
    try {
      // 获取参数
      const discordUser = interaction.options.getUser('目标用户');
      
      // 查找用户
      const user = await User.findOne({ discordId: discordUser.id });
      
      if (!user) {
        return interaction.reply({
          content: `找不到Discord用户 ${discordUser.tag} 的信息。`,
          ephemeral: true
        });
      }
      
      // 检查用户角色和权限
      const member = interaction.member;
      const isSelf = interaction.user.id === discordUser.id;
      const isAdmin = member.roles.cache.some(role => 
        role.name === config.roles.admin || role.name === config.roles.superAdmin
      );
      
      // 如果不是管理员且不是查询自己，则拒绝
      if (!isAdmin && !isSelf) {
        return interaction.reply({
          content: '您只能查看自己的信息，或者您需要管理员权限来查看其他用户的信息。',
          ephemeral: true
        });
      }
      
      // 构建用户信息
      let userInfo = `**用户信息**\n`;
      userInfo += `Discord: ${discordUser.tag}\n`;
      userInfo += `用户ID: ${user.userId || '未绑定'}\n`;
      userInfo += `绑定状态: ${user.boundId ? '已绑定' : '未绑定'}\n`;
      
      // 如果已绑定，显示绑定时间
      if (user.boundAt) {
        userInfo += `绑定时间: ${moment(user.boundAt).format('YYYY-MM-DD HH:mm:ss')}\n`;
      }
      
      // 如果是管理员或超级管理员，显示更多信息
      if (isAdmin) {
        userInfo += `角色: ${user.role}\n`;
        userInfo += `总配额: $${user.quota.toFixed(2)}\n`;
        userInfo += `已使用: $${user.usedQuota.toFixed(2)}\n`;
        userInfo += `剩余: $${(user.quota - user.usedQuota).toFixed(2)}\n`;
        userInfo += `创建时间: ${moment(user.createdAt).format('YYYY-MM-DD HH:mm:ss')}\n`;
        
        // 如果有最后更新时间
        if (user.lastQuotaUpdate) {
          userInfo += `最后配额更新: ${moment(user.lastQuotaUpdate).format('YYYY-MM-DD HH:mm:ss')}\n`;
        }
      }
      
      // 回复
      await interaction.reply({
        content: userInfo,
        ephemeral: true
      });
      
    } catch (error) {
      console.error('查询用户信息时出错:', error);
      await interaction.reply({
        content: '查询用户信息时发生错误，请稍后再试。',
        ephemeral: true
      });
    }
  }
};