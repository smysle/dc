/**
 * 交互处理器
 * 处理Discord交互事件，如按钮点击、选择菜单等
 */
const { User } = require('../models');
const { MessageActionRow, MessageButton } = require('discord.js');
const config = require('../config');

/**
 * 处理按钮交互
 * @param {Object} interaction - Discord交互对象
 */
async function handleButtonInteraction(interaction) {
  try {
    // 获取按钮自定义ID
    const customId = interaction.customId;
    
    // 处理增加额度按钮
    if (customId.startsWith('增加额度_')) {
      // 从自定义ID中提取用户ID
      const userId = customId.split('_')[1];
      
      // 查找用户 - 使用lean()获取普通JS对象
      const user = await User.findOne({ userId }).lean();
      
      if (!user) {
        return interaction.reply({
          content: '找不到用户信息，请联系管理员。',
          ephemeral: true
        });
      }
      
      // 获取配额常量
      const minQuota = config.quota.minQuotaDollars * config.quota.dollarsToQuota; // 50,000,000
      const addQuota = config.quota.addQuotaDollars * config.quota.dollarsToQuota; // 100,000,000
      
      // 创建辅助函数转换为美元格式
      const formatQuotaAsDollars = (quota) => `$${(quota / config.quota.dollarsToQuota).toFixed(2)}`;

      // 再次检查剩余配额（以防在点击按钮前已经有变化）
      const remainingQuota = user.quota - user.usedQuota;
      
      // 检查是否需要增加配额(直接比较配额单位)
      if (remainingQuota >= minQuota) {
        return interaction.reply({
          content: `您当前剩余配额为 ${remainingQuota} (${formatQuotaAsDollars(remainingQuota)})，高于 ${minQuota} (${formatQuotaAsDollars(minQuota)})，无需增加配额。`,
          ephemeral: true
        });
      }
      
      // 记录原始配额
      const originalQuota = user.quota;
      
      // 记录原始配额
      const originalQuota = user.quota;
      
      // 创建历史记录条目
      const historyEntry = {
        timestamp: new Date(),
        action: 'button_refill',
        amount: addQuota,
        reason: `用户通过按钮补充配额（余额低于${formatQuotaAsDollars(minQuota)}）`,
        adminId: 'user_self'
      };
      
      // 使用findOneAndUpdate进行部分更新，只更新必要字段
      const updatedUser = await User.findOneAndUpdate(
        { userId },
        {
          $inc: { quota: addQuota },           // 增加配额
          $push: { quotaHistory: historyEntry },  // 添加历史记录
          $set: { lastQuotaUpdate: new Date() }   // 更新最后配额更新时间
        },
        { new: true, runValidators: true }     // 返回更新后的文档，运行验证器
      );
      
      if (!updatedUser) {
        return interaction.reply({
          content: '更新配额时发生错误，请联系管理员。',
          ephemeral: true
        });
      }
      
      // 准备新的按钮（刷新按钮）
      const row = new MessageActionRow()
        .addComponents(
          new MessageButton()
            .setCustomId('refresh_balance')
            .setLabel('刷新余额')
            .setStyle('SECONDARY')
        );
      
      // 计算新配额
      const newQuota = originalQuota + addQuota;
      
      // 回复用户(同时显示原始配额和美元格式)
      await interaction.update({
        content: `**配额已成功增加!**\n` +
                 `原配额: ${originalQuota} (${formatQuotaAsDollars(originalQuota)})\n` +
                 `新配额: ${newQuota} (${formatQuotaAsDollars(newQuota)})\n` +
                 `增加配额: ${addQuota} (${formatQuotaAsDollars(addQuota)})\n\n` +
                 `您的余额现在充足，无需增加配额。\n\n` +
                 `注意：系统在更新配额时会保留您的所有原始信息，包括用户名、分组和访问令牌等。`,
        components: [row]
      });
    }
    
    // 处理刷新余额按钮
    else if (customId === 'refresh_balance') {
      const discordId = interaction.user.id;
      
      // 查找用户 - 使用lean()获取普通JS对象
      const user = await User.findOne({ discordId }).lean();
      
      if (!user) {
        return interaction.reply({
          content: '您尚未绑定ID，请联系管理员进行绑定。',
          ephemeral: true
        });
      }
      
      // 获取用户ID以便后续更新
      const userId = user.userId;
      
      // 获取配额常量
      const minQuota = config.quota.minQuotaDollars * config.quota.dollarsToQuota; // 50,000,000
      const addQuota = config.quota.addQuotaDollars * config.quota.dollarsToQuota; // 100,000,000
      
      // 创建辅助函数转换为美元格式
      const formatQuotaAsDollars = (quota) => `$${(quota / config.quota.dollarsToQuota).toFixed(2)}`;
      
      // 计算剩余配额
      const remainingQuota = user.quota - user.usedQuota;
      
      // 构建回复消息(同时显示原始配额和美元格式)
      let replyContent = `**余额信息** (已刷新)\n用户ID: ${user.userId}\n` +
                         `总配额: ${user.quota} (${formatQuotaAsDollars(user.quota)})\n` +
                         `已使用: ${user.usedQuota} (${formatQuotaAsDollars(user.usedQuota)})\n` +
                         `剩余: ${remainingQuota} (${formatQuotaAsDollars(remainingQuota)})`;
      
      // 根据余额状态准备不同的按钮
      let row;
      
      // 余额低于阈值(50,000,000)，显示"增加额度"按钮
      if (remainingQuota < minQuota) {
        row = new MessageActionRow()
          .addComponents(
            new MessageButton()
              .setCustomId('增加额度_' + user.userId)
              .setLabel(`增加额度 (${formatQuotaAsDollars(addQuota)})`)
              .setStyle('PRIMARY')
          );
        
        // 添加提示信息
        replyContent += `\n\n**提示**: 您的余额低于 ${formatQuotaAsDollars(minQuota)}，可以点击下方按钮增加 ${formatQuotaAsDollars(addQuota)} 配额。`;
      } else {
        row = new MessageActionRow()
          .addComponents(
            new MessageButton()
              .setCustomId('refresh_balance')
              .setLabel('刷新余额')
              .setStyle('SECONDARY')
          );
        
        replyContent += '\n\n您的余额充足，无需增加配额。';
      }
      
      // 更新消息
      await interaction.update({
        content: replyContent,
        components: [row]
      });
    }
    
  } catch (error) {
    console.error('处理按钮交互时出错:', error);
    // 尝试回复错误
    try {
      await interaction.reply({
        content: '处理请求时发生错误，请稍后再试。',
        ephemeral: true
      });
    } catch (replyError) {
      // 如果已经回复过了，使用followUp
      try {
        await interaction.followUp({
          content: '处理请求时发生错误，请稍后再试。',
          ephemeral: true
        });
      } catch (followUpError) {
        console.error('无法回复交互错误:', followUpError);
      }
    }
  }
}

module.exports = {
  handleButtonInteraction
};