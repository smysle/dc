const { User } = require('../models');
const config = require('../config');

module.exports = {
  name: 'unbind',
  description: '解除用户ID绑定 (仅限管理员和超级管理员使用)',
  async execute(message, args) {
    // 检查执行命令的用户是否有管理员权限
    const member = message.member;
    const isSuperAdmin = member.roles.cache.some(role => role.name === config.roles.superAdmin);
    const isAdmin = isSuperAdmin || member.roles.cache.some(role => role.name === config.roles.admin);
    
    if (!isAdmin) {
      return message.reply('你没有权限执行此命令，只有管理员和超级管理员可以解绑用户ID。');
    }
    
    // 检查参数
    if (args.length < 1) {
      return message.reply(`使用方法不正确。正确格式：${config.prefix}unbind <@用户>`);
    }
    
    // 获取目标用户
    const targetUser = message.mentions.users.first();
    if (!targetUser) {
      return message.reply('请正确提及(@)一个用户。');
    }
    
    try {
      // 查找用户记录
      const user = await User.findOne({ discordId: targetUser.id });
      
      if (!user) {
        return message.reply(`用户 <@${targetUser.id}> 在数据库中不存在。`);
      }
      
      // 检查用户是否绑定了ID
      if (!user.boundId) {
        return message.reply(`用户 <@${targetUser.id}> 尚未绑定任何ID。`);
      }
      
      // 记录当前绑定的ID，以便在解绑消息中显示
      const previousId = user.boundId;
      
      // 解除绑定
      user.boundId = null;
      user.boundBy = null;
      user.boundAt = null;
      
      // 保存用户记录
      await user.save();
      
      message.reply(`成功为用户 <@${targetUser.id}> 解除ID "${previousId}" 的绑定。`);
    } catch (error) {
      console.error('解绑ID时出错:', error);
      message.reply('解绑ID时发生错误，请稍后再试。');
    }
  }
};