const express = require('express');
const router = express.Router();
const { User } = require('../../models');
const config = require('../../config');
const { updateUsedQuota, checkAndRefillQuota } = require('../../utils/quota-manager');

// 中间件：检查API认证
const checkApiAuth = (req, res, next) => {
  if (!req.session.user) {
    return res.status(401).json({ success: false, message: '未授权' });
  }
  next();
};

/**
 * 使用配额API
 * 当用户使用服务时，增加已使用的配额
 */
router.post('/use', async (req, res) => {
  try {
    const { userId, amount, description } = req.body;
    
    if (!userId) {
      return res.status(400).json({ success: false, message: '请提供用户ID' });
    }
    
    if (!amount || isNaN(amount) || amount <= 0) {
      return res.status(400).json({ success: false, message: '请提供有效的使用金额' });
    }
    
    // 查找用户
    const user = await User.findOne({ userId });
    
    if (!user) {
      return res.status(404).json({ success: false, message: '用户不存在' });
    }
    
    // 检查余额是否足够
    if (user.quota - user.usedQuota < amount) {
      return res.status(400).json({
        success: false,
        message: '用户余额不足',
        data: {
          quota: user.quota,
          usedQuota: user.usedQuota,
          remainingQuota: user.quota - user.usedQuota,
          requestedAmount: amount,
          needsRefill: true
        }
      });
    }
    
    // 更新使用的配额
    user.usedQuota += amount;
    
    // 添加使用记录
    user.quotaHistory.push({
      timestamp: new Date(),
      action: 'use',
      amount: amount,
      reason: description || '使用配额',
      adminId: req.session.user ? req.session.user.username : 'api'
    });
    
    // 保存用户
    await user.save();
    
    // 计算更新后的剩余配额
    const remainingQuota = user.quota - user.usedQuota;
    
    // 返回结果
    res.json({
      success: true,
      message: '配额已使用',
      data: {
        user: user,
        usedAmount: amount,
        remainingQuota: remainingQuota,
        needsRefill: remainingQuota < 100
      }
    });
    
  } catch (error) {
    console.error('使用配额时出错:', error);
    res.status(500).json({ success: false, message: '使用配额时发生错误', error: error.message });
  }
});

/**
 * 检查用户配额状态
 * 查询用户剩余配额
 */
router.get('/check/:userId', async (req, res) => {
  try {
    const { userId } = req.params;
    
    if (!userId) {
      return res.status(400).json({ success: false, message: '请提供用户ID' });
    }
    
    // 查找用户
    const user = await User.findOne({ userId });
    
    if (!user) {
      return res.status(404).json({ success: false, message: '用户不存在' });
    }
    
    // 计算剩余配额
    const remainingQuota = user.quota - user.usedQuota;
    
    // 返回结果
    res.json({
      success: true,
      data: {
        user: user,
        quota: user.quota,
        usedQuota: user.usedQuota,
        remainingQuota: remainingQuota,
        needsRefill: remainingQuota < 100
      }
    });
    
  } catch (error) {
    console.error('检查配额时出错:', error);
    res.status(500).json({ success: false, message: '检查配额时发生错误', error: error.message });
  }
});

/**
 * 增加用户配额
 * 当用户余额低于100$时，增加200$配额
 */
router.post('/refill/:userId', async (req, res) => {
  try {
    const { userId } = req.params;
    
    if (!userId) {
      return res.status(400).json({ success: false, message: '请提供用户ID' });
    }
    
    // 查找用户
    const user = await User.findOne({ userId });
    
    if (!user) {
      return res.status(404).json({ success: false, message: '用户不存在' });
    }
    
    // 计算剩余配额
    const remainingQuota = user.quota - user.usedQuota;
    
    // 检查是否需要增加配额
    if (remainingQuota >= 100) {
      return res.status(400).json({
        success: false,
        message: '用户余额高于$100，无需增加配额',
        data: {
          remainingQuota,
          quota: user.quota,
          usedQuota: user.usedQuota
        }
      });
    }
    
    // 记录原始配额
    const originalQuota = user.quota;
    
    // 增加配额
    user.quota += 200;
    
    // 添加配额历史记录
    user.quotaHistory.push({
      timestamp: new Date(),
      action: 'api_refill',
      amount: 200,
      reason: '通过API补充配额（余额低于$100）',
      adminId: req.session.user ? req.session.user.username : 'api'
    });
    
    // 保存用户
    await user.save();
    
    // 返回结果
    res.json({
      success: true,
      message: '配额已成功增加',
      data: {
        user: user,
        previousQuota: originalQuota,
        currentQuota: user.quota,
        refillAmount: 200,
        newRemainingQuota: user.quota - user.usedQuota
      }
    });
    
  } catch (error) {
    console.error('增加配额时出错:', error);
    res.status(500).json({ success: false, message: '增加配额时发生错误', error: error.message });
  }
});

module.exports = router;