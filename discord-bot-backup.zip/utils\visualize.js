/**
 * 数据可视化工具
 * 用于生成丰富的数据图表和可视化展示
 */

/**
 * 生成配额统计图表配置
 * @param {Object} data - 配额统计数据
 * @param {string} type - 图表类型 (daily, weekly, monthly)
 * @returns {Object} - Chart.js配置
 */
function generateQuotaChartConfig(data, type = 'daily') {
  // 处理时间标签
  let timeLabels = [];
  let dataPoints = [];
  let avgLine = [];
  
  if (type === 'daily') {
    // 每小时数据
    timeLabels = Array.from({ length: 24 }, (_, i) => `${i}:00`);
    
    // 填充数据点
    if (data && data.hourly) {
      dataPoints = Array(24).fill(0);
      data.hourly.forEach(point => {
        const hour = new Date(point.timestamp).getHours();
        dataPoints[hour] += point.amount;
      });
    }
    
    // 计算平均值
    if (dataPoints.length > 0) {
      const avg = dataPoints.reduce((sum, val) => sum + val, 0) / 24;
      avgLine = Array(24).fill(avg);
    }
  } else if (type === 'weekly') {
    // 每天数据
    const days = ['周日', '周一', '周二', '周三', '周四', '周五', '周六'];
    timeLabels = days;
    
    // 填充数据点
    if (data && data.daily) {
      dataPoints = Array(7).fill(0);
      data.daily.forEach(point => {
        const day = new Date(point.timestamp).getDay();
        dataPoints[day] += point.amount;
      });
    }
    
    // 计算平均值
    if (dataPoints.length > 0) {
      const avg = dataPoints.reduce((sum, val) => sum + val, 0) / 7;
      avgLine = Array(7).fill(avg);
    }
  } else if (type === 'monthly') {
    // 每月数据
    timeLabels = Array.from({ length: 30 }, (_, i) => `${i + 1}日`);
    
    // 填充数据点
    if (data && data.monthly) {
      dataPoints = Array(30).fill(0);
      data.monthly.forEach(point => {
        const day = new Date(point.timestamp).getDate() - 1;
        if (day < 30) {
          dataPoints[day] += point.amount;
        }
      });
    }
    
    // 计算平均值
    if (dataPoints.length > 0) {
      const avg = dataPoints.reduce((sum, val) => sum + val, 0) / 30;
      avgLine = Array(30).fill(avg);
    }
  }
  
  // 创建图表配置
  return {
    type: 'bar',
    data: {
      labels: timeLabels,
      datasets: [
        {
          label: '配额变化',
          data: dataPoints,
          backgroundColor: 'rgba(54, 162, 235, 0.5)',
          borderColor: 'rgb(54, 162, 235)',
          borderWidth: 1
        },
        {
          label: '平均值',
          data: avgLine,
          type: 'line',
          fill: false,
          borderColor: 'rgb(255, 99, 132)',
          borderDash: [5, 5],
          pointRadius: 0
        }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      scales: {
        y: {
          beginAtZero: true,
          title: {
            display: true,
            text: '配额数量'
          }
        },
        x: {
          title: {
            display: true,
            text: type === 'daily' ? '小时' : (type === 'weekly' ? '星期' : '日期')
          }
        }
      },
      plugins: {
        title: {
          display: true,
          text: type === 'daily' ? '每日配额统计' : (type === 'weekly' ? '每周配额统计' : '每月配额统计')
        },
        tooltip: {
          mode: 'index',
          intersect: false
        }
      }
    }
  };
}

/**
 * 生成用户统计图表配置
 * @param {Object} data - 用户统计数据
 * @returns {Object} - Chart.js配置
 */
function generateUserStatsChartConfig(data) {
  // 默认数据
  const userData = {
    total: 0,
    bound: 0,
    unbound: 0,
    active: 0,
    inactive: 0
  };
  
  // 合并实际数据
  if (data) {
    Object.assign(userData, data);
  }
  
  // 创建图表配置
  return {
    type: 'pie',
    data: {
      labels: ['已绑定ID', '未绑定ID', '活跃用户', '非活跃用户'],
      datasets: [{
        data: [
          userData.bound,
          userData.unbound,
          userData.active,
          userData.inactive
        ],
        backgroundColor: [
          'rgba(54, 162, 235, 0.5)',
          'rgba(255, 99, 132, 0.5)',
          'rgba(75, 192, 192, 0.5)',
          'rgba(255, 206, 86, 0.5)'
        ],
        borderColor: [
          'rgb(54, 162, 235)',
          'rgb(255, 99, 132)',
          'rgb(75, 192, 192)',
          'rgb(255, 206, 86)'
        ],
        borderWidth: 1
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        title: {
          display: true,
          text: '用户统计'
        },
        legend: {
          position: 'bottom'
        },
        tooltip: {
          callbacks: {
            label: function(context) {
              const label = context.label || '';
              const value = context.raw || 0;
              const total = userData.total || 1;
              const percentage = Math.round((value / total) * 100);
              return `${label}: ${value} (${percentage}%)`;
            }
          }
        }
      }
    }
  };
}

/**
 * 生成配额分布图表配置
 * @param {Array} data - 配额分布数据
 * @returns {Object} - Chart.js配置
 */
function generateQuotaDistributionChartConfig(data = []) {
  // 处理数据
  const ranges = [
    '0-100', '101-500', '501-1000', '1001-5000', 
    '5001-10000', '10001-50000', '50001+'
  ];
  
  // 默认分布
  const distribution = Array(ranges.length).fill(0);
  
  // 填充实际分布
  if (data && data.length > 0) {
    data.forEach(user => {
      const quota = user.quota || 0;
      
      if (quota <= 100) distribution[0]++;
      else if (quota <= 500) distribution[1]++;
      else if (quota <= 1000) distribution[2]++;
      else if (quota <= 5000) distribution[3]++;
      else if (quota <= 10000) distribution[4]++;
      else if (quota <= 50000) distribution[5]++;
      else distribution[6]++;
    });
  }
  
  // 创建图表配置
  return {
    type: 'bar',
    data: {
      labels: ranges,
      datasets: [{
        label: '用户数量',
        data: distribution,
        backgroundColor: 'rgba(75, 192, 192, 0.5)',
        borderColor: 'rgb(75, 192, 192)',
        borderWidth: 1
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      scales: {
        y: {
          beginAtZero: true,
          title: {
            display: true,
            text: '用户数量'
          }
        },
        x: {
          title: {
            display: true,
            text: '配额范围'
          }
        }
      },
      plugins: {
        title: {
          display: true,
          text: '配额分布'
        },
        tooltip: {
          mode: 'index',
          intersect: false
        }
      }
    }
  };
}

/**
 * 生成活跃度热力图配置
 * @param {Array} data - 活跃度数据
 * @returns {Object} - Chart.js配置
 */
function generateActivityHeatmapConfig(data = []) {
  // 生成过去30天的日期
  const dates = [];
  const now = new Date();
  for (let i = 29; i >= 0; i--) {
    const date = new Date(now);
    date.setDate(now.getDate() - i);
    dates.push(date.toISOString().split('T')[0]);
  }
  
  // 初始化活跃度数据
  const activityData = {};
  dates.forEach(date => {
    activityData[date] = 0;
  });
  
  // 填充实际活跃度
  if (data && data.length > 0) {
    data.forEach(activity => {
      const date = new Date(activity.timestamp).toISOString().split('T')[0];
      if (activityData[date] !== undefined) {
        activityData[date] += activity.count || 1;
      }
    });
  }
  
  // 将数据转换为数组
  const chartData = Object.values(activityData);
  
  // 创建图表配置
  return {
    type: 'line',
    data: {
      labels: dates.map(date => {
        const d = new Date(date);
        return `${d.getMonth() + 1}/${d.getDate()}`;
      }),
      datasets: [{
        label: '活跃度',
        data: chartData,
        fill: true,
        backgroundColor: 'rgba(153, 102, 255, 0.2)',
        borderColor: 'rgb(153, 102, 255)',
        tension: 0.4
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      scales: {
        y: {
          beginAtZero: true,
          title: {
            display: true,
            text: '活跃度'
          }
        },
        x: {
          title: {
            display: true,
            text: '日期'
          }
        }
      },
      plugins: {
        title: {
          display: true,
          text: '30天活跃度'
        }
      }
    }
  };
}

/**
 * 生成系统使用趋势图表配置
 * @param {Object} data - 系统使用数据
 * @returns {Object} - Chart.js配置
 */
function generateSystemUsageTrendConfig(data = {}) {
  // 默认数据
  const defaultData = {
    dates: [],
    commands: [],
    apiCalls: [],
    errors: []
  };
  
  // 合并实际数据
  const chartData = { ...defaultData, ...data };
  
  // 创建图表配置
  return {
    type: 'line',
    data: {
      labels: chartData.dates,
      datasets: [
        {
          label: 'Bot命令',
          data: chartData.commands,
          borderColor: 'rgb(54, 162, 235)',
          backgroundColor: 'rgba(54, 162, 235, 0.1)',
          fill: true,
          tension: 0.4,
          yAxisID: 'y'
        },
        {
          label: 'API调用',
          data: chartData.apiCalls,
          borderColor: 'rgb(75, 192, 192)',
          backgroundColor: 'rgba(75, 192, 192, 0.1)',
          fill: true,
          tension: 0.4,
          yAxisID: 'y'
        },
        {
          label: '错误',
          data: chartData.errors,
          borderColor: 'rgb(255, 99, 132)',
          backgroundColor: 'rgba(255, 99, 132, 0.1)',
          fill: true,
          tension: 0.4,
          yAxisID: 'y1'
        }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      interaction: {
        mode: 'index',
        intersect: false
      },
      scales: {
        y: {
          type: 'linear',
          display: true,
          position: 'left',
          title: {
            display: true,
            text: '命令和API调用数量'
          }
        },
        y1: {
          type: 'linear',
          display: true,
          position: 'right',
          title: {
            display: true,
            text: '错误数量'
          },
          grid: {
            drawOnChartArea: false
          }
        }
      },
      plugins: {
        title: {
          display: true,
          text: '系统使用趋势'
        }
      }
    }
  };
}

module.exports = {
  generateQuotaChartConfig,
  generateUserStatsChartConfig,
  generateQuotaDistributionChartConfig,
  generateActivityHeatmapConfig,
  generateSystemUsageTrendConfig
};