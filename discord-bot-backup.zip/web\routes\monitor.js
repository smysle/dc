const express = require('express');
const router = express.Router();
const { getMonitorData, getSystemSummary } = require('../../utils/monitor');

// 辅助函数: 格式化持续时间
function formatDuration(ms) {
  const seconds = Math.floor(ms / 1000);
  const minutes = Math.floor(seconds / 60);
  const hours = Math.floor(minutes / 60);
  const days = Math.floor(hours / 24);
  
  if (days > 0) {
    return `${days}天 ${hours % 24}小时`;
  } else {
    return `${hours}小时 ${minutes % 60}分钟`;
  }
}

// 中间件：检查是否已登录
const isAuthenticated = (req, res, next) => {
  if (req.session.user) {
    return next();
  }
  res.redirect('/login');
};

// 系统监控页面
router.get('/', isAuthenticated, (req, res) => {
  const summary = getSystemSummary();
  
  // 将数据传递为JSON字符串，避免EJS和JavaScript混合问题
  const summaryJson = JSON.stringify(summary);
  
  res.render('monitor/index', {
    title: '系统监控',
    user: req.session.user,
    summaryJson,
    formatDuration
  });
});

// 获取实时监控数据的API端点
router.get('/api/data', isAuthenticated, (req, res) => {
  const section = req.query.section;
  const data = getMonitorData(section);
  
  res.json({
    success: true,
    data
  });
});

// 获取系统摘要的API端点
router.get('/api/summary', isAuthenticated, (req, res) => {
  const summary = getSystemSummary();
  
  res.json({
    success: true,
    data: summary
  });
});

// 获取详细资源使用情况
router.get('/api/resources', isAuthenticated, (req, res) => {
  const data = getMonitorData('system');
  
  // 获取最近的数据点
  const recentPoints = {
    cpu: data.cpuUsage.slice(-60), // 最近60个数据点
    memory: data.memoryUsage.slice(-60),
    heap: data.heapUsage.slice(-60)
  };
  
  res.json({
    success: true,
    data: recentPoints
  });
});

// 获取请求统计
router.get('/api/requests', isAuthenticated, (req, res) => {
  const data = getMonitorData('requests');
  
  // 按路由汇总
  const routeStats = Object.entries(data.routes).map(([route, stats]) => ({
    route,
    ...stats,
    successRate: stats.total > 0 ? (stats.success / stats.total) * 100 : 100
  })).sort((a, b) => b.total - a.total);
  
  // 获取最近的响应时间
  const recentResponseTimes = data.responseTime.slice(-100);
  
  res.json({
    success: true,
    data: {
      total: data.total,
      success: data.success,
      failed: data.failed,
      successRate: data.total > 0 ? (data.success / data.total) * 100 : 100,
      routes: routeStats,
      responseTimes: recentResponseTimes
    }
  });
});

// 获取错误统计
router.get('/api/errors', isAuthenticated, (req, res) => {
  const data = getMonitorData('errors');
  
  // 按类型汇总
  const errorTypes = Object.entries(data.types).map(([type, count]) => ({
    type,
    count
  })).sort((a, b) => b.count - a.count);
  
  res.json({
    success: true,
    data: {
      total: data.total,
      types: errorTypes,
      recent: data.recent.slice(0, 20) // 最近20个错误
    }
  });
});

// 获取数据库统计
router.get('/api/database', isAuthenticated, (req, res) => {
  const data = getMonitorData('database');
  
  res.json({
    success: true,
    data
  });
});

module.exports = router;