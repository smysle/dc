#!/bin/bash
# 初始化Git仓库并上传到GitHub的脚本

# 颜色设置
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
NC='\033[0m' # No Color

echo -e "${GREEN}Discord配额管理系统 - GitHub上传脚本${NC}"
echo "========================================"

# 检查Git是否安装
if ! command -v git &> /dev/null; then
    echo -e "${RED}错误: Git未安装。请先安装Git后再运行此脚本。${NC}"
    exit 1
fi

# 询问GitHub用户信息
read -p "请输入GitHub用户名: " github_username
read -p "请输入仓库名称 (默认: discord-quota-manager): " repo_name
repo_name=${repo_name:-discord-quota-manager}

read -p "请输入仓库描述 (默认: Discord用户配额管理系统): " repo_description
repo_description=${repo_description:-"Discord用户配额管理系统"}

# 创建.gitignore文件（如果不存在）
if [ ! -f .gitignore ]; then
    echo -e "${YELLOW}创建.gitignore文件...${NC}"
    cat > .gitignore << EOL
# 依赖目录
node_modules/
npm-debug.log
yarn-debug.log
yarn-error.log

# 环境变量
.env
.env.local
.env.development.local
.env.test.local
.env.production.local

# 数据目录
data/

# 日志
logs/
*.log

# 编辑器和系统文件
.idea/
.vscode/
.DS_Store
Thumbs.db

# 临时文件
tmp/
temp/
EOL
    echo -e "${GREEN}.gitignore文件已创建${NC}"
fi

# 初始化Git仓库
echo -e "${YELLOW}初始化Git仓库...${NC}"
git init

# 添加所有文件
echo -e "${YELLOW}添加文件到暂存区...${NC}"
git add .

# 提交初始更改
echo -e "${YELLOW}提交初始更改...${NC}"
git commit -m "初始提交: Discord配额管理系统"

# 创建GitHub仓库
echo -e "${YELLOW}正在创建GitHub仓库: $repo_name...${NC}"
echo -e "${YELLOW}请在浏览器中完成GitHub授权...${NC}"

# 使用gh命令创建仓库（如果安装了GitHub CLI）
if command -v gh &> /dev/null; then
    gh repo create "$repo_name" --public --description "$repo_description" --source=. --remote=origin
else
    # 否则提供手动创建的指南
    echo -e "${YELLOW}GitHub CLI未安装，请手动在GitHub上创建仓库:${NC}"
    echo "1. 访问 https://github.com/new"
    echo "2. 仓库名设置为: $repo_name"
    echo "3. 描述设置为: $repo_description"
    echo "4. 选择公开仓库"
    echo "5. 不要初始化README, .gitignore或许可证"
    echo "6. 点击'创建仓库'"
    echo ""
    
    read -p "完成创建后按Enter继续..."
    
    # 询问仓库URL
    read -p "请输入GitHub仓库URL: " repo_url
    
    # 添加远程仓库
    echo -e "${YELLOW}添加远程仓库...${NC}"
    git remote add origin "$repo_url"
fi

# 推送到GitHub
echo -e "${YELLOW}推送代码到GitHub...${NC}"
git push -u origin master || git push -u origin main

echo ""
echo -e "${GREEN}✓ 完成!${NC}"
echo -e "仓库已上传到: ${GREEN}https://github.com/$github_username/$repo_name${NC}"
echo ""
echo "其他有用的Git命令:"
echo "- 查看状态: git status"
echo "- 添加文件: git add <文件名>"
echo "- 提交更改: git commit -m \"更改描述\""
echo "- 推送更改: git push"
echo "- 拉取更新: git pull"