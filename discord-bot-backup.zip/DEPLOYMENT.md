# 生产环境部署指南

本文档提供在生产环境中部署Discord用户管理与配额系统的详细步骤。

## 系统要求

- Node.js 16.x 或更高版本
- MongoDB 4.4 或更高版本
- 至少 2GB RAM (推荐 4GB+)
- 现代操作系统 (Linux、Windows Server 等)

## 部署步骤

### 1. 准备服务器环境

#### 安装 Node.js
```bash
# 使用 NVM 安装 Node.js (Linux/macOS)
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.1/install.sh | bash
source ~/.bashrc
nvm install 16
nvm use 16

# 或直接从官网下载安装包
# https://nodejs.org/
```

#### 安装 MongoDB
```bash
# Ubuntu 示例
wget -qO - https://www.mongodb.org/static/pgp/server-4.4.asc | sudo apt-key add -
echo "deb [ arch=amd64,arm64 ] https://repo.mongodb.org/apt/ubuntu focal/mongodb-org/4.4 multiverse" | sudo tee /etc/apt/sources.list.d/mongodb-org-4.4.list
sudo apt-get update
sudo apt-get install -y mongodb-org
sudo systemctl start mongod
sudo systemctl enable mongod

# 其他系统请参考 MongoDB 官方文档
# https://docs.mongodb.com/manual/installation/
```

#### 安装 PM2 进程管理器
```bash
npm install -g pm2
```

### 2. 配置项目

#### 克隆代码到服务器
```bash
git clone <你的代码仓库URL> discord-bot
cd discord-bot
```

#### 安装依赖
```bash
npm install --legacy-peer-deps
```

#### 创建环境配置文件
创建 `.env` 文件，填入以下内容：

```
# Discord Bot Token (从 Discord 开发者平台获取)
BOT_TOKEN=your_discord_bot_token

# MongoDB Connection URI (生产环境推荐使用认证)
MONGODB_URI=mongodb://username:password@localhost:27017/discord-bot

# Discord Bot Settings
CLIENT_ID=your_client_id
GUILD_ID=your_guild_id

# Web 服务器配置
PORT=3000
NODE_ENV=production
SESSION_SECRET=your-long-and-secure-random-session-secret
```

### 3. 配置 MongoDB 安全性

#### 创建数据库用户
```bash
mongo
> use discord-bot
> db.createUser({
    user: "dbuser", 
    pwd: "secure-password", 
    roles: [{ role: "readWrite", db: "discord-bot" }]
  })
> exit
```

#### 启用认证
编辑 MongoDB 配置文件 `/etc/mongod.conf`，添加：

```yaml
security:
  authorization: enabled
```

重启 MongoDB：
```bash
sudo systemctl restart mongod
```

### 4. 启动应用

#### 使用 PM2 运行应用
```bash
pm2 start index.js --name discord-bot
```

#### 配置自动启动
```bash
pm2 startup
pm2 save
```

#### 查看日志
```bash
pm2 logs discord-bot
```

### 5. 配置 Web 服务器

如果你想使用 Nginx 作为反向代理，可以按照以下步骤配置：

#### 安装 Nginx
```bash
sudo apt-get install nginx
```

#### 配置 Nginx 反向代理
创建配置文件 `/etc/nginx/sites-available/discord-bot`：

```nginx
server {
    listen 80;
    server_name your-domain.com;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

启用站点并重启 Nginx：
```bash
sudo ln -s /etc/nginx/sites-available/discord-bot /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
```

### 6. 配置 HTTPS (推荐)

使用 Let's Encrypt 获取免费 SSL 证书：

```bash
sudo apt-get install certbot python3-certbot-nginx
sudo certbot --nginx -d your-domain.com
```

### 7. 系统维护

#### 更新应用
```bash
cd discord-bot
git pull
npm install --legacy-peer-deps
pm2 restart discord-bot
```

#### 备份数据库
```bash
mongodump --uri="mongodb://username:password@localhost:27017/discord-bot" --out=/path/to/backup/folder
```

#### 监控应用状态
```bash
pm2 monit
```

## 故障排除

### MongoDB 连接问题
- 检查 MongoDB 服务是否运行: `systemctl status mongod`
- 检查防火墙设置: `sudo ufw status`
- 检查连接字符串是否正确

### Discord Bot 不响应
- 检查 Bot Token 是否有效
- 检查 Bot 是否有正确的权限
- 查看 PM2 日志: `pm2 logs discord-bot`

### Web 界面无法访问
- 检查 Node.js 服务是否运行: `pm2 status`
- 检查端口是否被占用: `netstat -tuln | grep 3000`
- 检查 Nginx 配置: `nginx -t`
- 检查防火墙设置: `sudo ufw status`

## 性能优化

### MongoDB 优化
- 为大型部署启用分片: [MongoDB 分片文档](https://docs.mongodb.com/manual/sharding/)
- 调整 WiredTiger 缓存大小: 设置为可用RAM的60%
- 创建适当的索引: 已在代码中实现关键索引

### Node.js 优化
- 增加 Node.js 内存限制: `pm2 start index.js --node-args="--max-old-space-size=4096"`
- 启用集群模式: `pm2 start index.js -i max`

## 安全建议

- 定期更新所有依赖包: `npm audit fix`
- 启用防火墙，只开放必要端口
- 使用复杂密码并定期更换
- 定期备份数据库
- 配置服务器自动安全更新