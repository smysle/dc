const { SlashCommandBuilder } = require('@discordjs/builders');
const { User } = require('../models');
const config = require('../config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('balance')
    .setDescription('查询自己的余额'),
    
  async execute(interaction) {
    try {
      const discordId = interaction.user.id;
      
      // 查找用户
      const user = await User.findOne({ discordId });
      
      if (!user) {
        return interaction.reply({
          content: '您尚未绑定ID，请联系管理员进行绑定。',
          ephemeral: true
        });
      }
      
      // 格式化余额显示
      const formattedQuota = user.quota.toFixed(2);
      const formattedUsedQuota = user.usedQuota.toFixed(2);
      const formattedRemaining = (user.quota - user.usedQuota).toFixed(2);
      
      // 构建回复消息
      let replyContent = `**余额信息**\n用户ID: ${user.userId}\n总余额: $${formattedQuota}\n已使用: $${formattedUsedQuota}\n剩余: $${formattedRemaining}`;
      
      // 添加提示，如果余额低于100$
      if (user.quota - user.usedQuota < 100) {
        replyContent += `\n\n**提示**: 您的余额低于 $100，可以使用 \`!addquota\` 命令增加 $200 配额。`;
      }
      
      // 发送余额信息
      await interaction.reply({
        content: replyContent,
        ephemeral: true // 只有用户自己可见
      });
      
    } catch (error) {
      console.error('查询余额时出错:', error);
      await interaction.reply({
        content: '查询余额时发生错误，请稍后再试。',
        ephemeral: true
      });
    }
  }
};