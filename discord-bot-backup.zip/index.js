const { Client, GatewayIntentBits, Events, Collection } = require('discord.js');
const { connectDB } = require('./models');
const { handleCommand } = require('./commands');
const { handleButtonInteraction } = require('./utils/interaction-handler');
const { handleSelectMenuInteraction } = require('./utils/select-menu-handler');
const config = require('./config');
const { startServer } = require('./web/server');
const { startMonitoring } = require('./utils/monitor');

// 创建Discord客户端实例，并设置必要的权限
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.DirectMessages, // 添加私聊支持
  ],
});

// 创建命令集合
client.commands = new Collection();

// 当机器人准备就绪时
client.once(Events.ClientReady, () => {
  console.log(`已登录为 ${client.user.tag}`);
  global.botUser = client.user;
  
  // 检查所需的角色是否存在
  client.guilds.cache.forEach(guild => {
    console.log(`检查服务器: ${guild.name}`);
    global.discordGuild = guild;
    
    // 检查超级管理员角色
    if (!guild.roles.cache.some(role => role.name === config.roles.superAdmin)) {
      console.log(`警告: 服务器 ${guild.name} 中不存在 "${config.roles.superAdmin}" 角色。`);
    }
    
    // 检查管理员角色
    if (!guild.roles.cache.some(role => role.name === config.roles.admin)) {
      console.log(`警告: 服务器 ${guild.name} 中不存在 "${config.roles.admin}" 角色。`);
    }
  });
});

// 当收到消息时
client.on(Events.MessageCreate, async message => {
  // 处理命令
  await handleCommand(message);
});

// 添加交互处理（按钮、选择菜单等）
client.on(Events.InteractionCreate, async interaction => {
  try {
    // 处理按钮交互
    if (interaction.isButton()) {
      await handleButtonInteraction(interaction);
    }
    // 处理选择菜单交互
    else if (interaction.isSelectMenu()) {
      await handleSelectMenuInteraction(interaction);
    }
    // 处理斜杠命令
    else if (interaction.isChatInputCommand()) {
      const command = client.commands.get(interaction.commandName);
      if (!command) return;
      
      await command.execute(interaction);
    }
  } catch (error) {
    console.error('处理交互时出错:', error);
    try {
      await interaction.reply({
        content: '执行命令时出现错误!',
        ephemeral: true
      });
    } catch (replyError) {
      // 可能已经回复过了
      console.error('无法回复交互错误:', replyError);
    }
  }
});

// 全局共享客户端实例
global.discordClient = client;

// 启动Bot客户端
const startBot = async () => {
  // 检查Bot Token是否已配置
  if (!config.bot.token) {
    console.log('Discord Bot Token未配置，Bot将不会启动');
    return false;
  }
  
  try {
    // 加载所有命令文件
    const fs = require('fs');
    const path = require('path');
    const commandsPath = path.join(__dirname, 'commands');
    const commandFiles = fs.readdirSync(commandsPath).filter(file =>
      file.endsWith('.js') && file !== 'index.js'
    );
    
    // 遍历每个命令文件并注册
    for (const file of commandFiles) {
      const filePath = path.join(commandsPath, file);
      const command = require(filePath);
      
      // 设置新命令
      if ('data' in command && 'execute' in command) {
        client.commands.set(command.data.name, command);
        console.log(`已加载命令: ${command.data.name}`);
      } else {
        console.log(`[警告] 命令 ${filePath} 缺少必要的 "data" 或 "execute" 属性`);
      }
    }
    
    console.log(`已加载 ${client.commands.size} 个命令`);
    
    // 登录Discord
    await client.login(config.bot.token);
    return true;
  } catch (error) {
    console.error('Discord Bot登录失败:', error);
    return false;
  }
};

// 连接到MongoDB数据库，然后启动Discord机器人和Web服务器
(async () => {
  try {
    // 连接到数据库并加载设置
    const { isConfigured } = await connectDB();
    
    // 设置全局配置状态
    global.systemStatus = {
      databaseConnected: true,
      botRunning: false,
      webServerRunning: false,
      needsConfiguration: !isConfigured
    };
    
    // 启动Web服务器（始终启动，即使未配置系统）
    const webServer = await startServer();
    global.systemStatus.webServerRunning = !!webServer;
    
    // 启动监控系统
    startMonitoring();
    console.log('系统监控已启动');
    
    // 如果系统已配置，尝试启动Bot
    if (isConfigured) {
      const botStarted = await startBot();
      global.systemStatus.botRunning = botStarted;
      
      if (botStarted) {
        console.log('Discord Bot已成功启动');
      } else {
        console.log('Discord Bot启动失败，请检查配置');
      }
    } else {
      console.log('系统尚未配置，请访问Web界面完成初始设置');
    }
    
    console.log('系统状态:', global.systemStatus);
  } catch (error) {
    console.error('启动服务时出错:', error);
    process.exit(1);
  }
})();

// 处理进程退出
process.on('SIGINT', () => {
  console.log('正在关闭...');
  client.destroy();
  process.exit(0);
});

process.on('SIGTERM', () => {
  console.log('正在关闭...');
  client.destroy();
  process.exit(0);
});