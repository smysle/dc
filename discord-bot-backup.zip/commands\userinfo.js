const { EmbedBuilder } = require('discord.js');
const { User } = require('../models');
const config = require('../config');

module.exports = {
  name: 'userinfo',
  description: '查看用户信息 (仅限管理员和超级管理员使用)',
  async execute(message, args) {
    // 检查执行命令的用户是否有管理员权限
    const member = message.member;
    const isSuperAdmin = member.roles.cache.some(role => role.name === config.roles.superAdmin);
    const isAdmin = isSuperAdmin || member.roles.cache.some(role => role.name === config.roles.admin);
    
    if (!isAdmin) {
      return message.reply('你没有权限执行此命令，只有管理员和超级管理员可以查看用户详细信息。');
    }
    
    // 检查参数
    if (args.length < 1) {
      return message.reply(`使用方法不正确。正确格式：${config.prefix}userinfo <@用户>`);
    }
    
    // 获取目标用户
    const targetUser = message.mentions.users.first();
    if (!targetUser) {
      return message.reply('请正确提及(@)一个用户。');
    }
    
    try {
      // 查找用户记录
      const user = await User.findOne({ discordId: targetUser.id });
      
      if (!user) {
        return message.reply(`用户 <@${targetUser.id}> 在数据库中不存在。`);
      }
      
      // 创建嵌入消息
      const embed = new EmbedBuilder()
        .setTitle('用户信息')
        .setColor('#0099ff')
        .setThumbnail(targetUser.displayAvatarURL({ dynamic: true }))
        .addFields(
          { name: '用户名', value: targetUser.username, inline: true },
          { name: 'Discord ID', value: targetUser.id, inline: true },
          { name: '角色', value: user.role || '普通用户', inline: true },
          { name: '绑定的ID', value: user.boundId ? user.boundId : '未绑定', inline: true }
        );
      
      // 如果有绑定记录，添加相关信息
      if (user.boundId) {
        // 获取绑定操作的管理员信息
        const adminInfo = user.boundBy ? `<@${user.boundBy}>` : '未知';
        
        // 格式化绑定时间
        const boundTime = user.boundAt 
          ? new Date(user.boundAt).toLocaleString('zh-CN', {
              year: 'numeric', 
              month: '2-digit', 
              day: '2-digit',
              hour: '2-digit',
              minute: '2-digit'
            }) 
          : '未知';
        
        embed.addFields(
          { name: '绑定操作管理员', value: adminInfo, inline: true },
          { name: '绑定时间', value: boundTime, inline: true }
        );
      }
      
      // 添加账户创建时间
      if (user.createdAt) {
        const createdTime = new Date(user.createdAt).toLocaleString('zh-CN', {
          year: 'numeric', 
          month: '2-digit', 
          day: '2-digit',
          hour: '2-digit',
          minute: '2-digit'
        });
        
        embed.addFields(
          { name: '账户创建时间', value: createdTime, inline: true }
        );
      }
      
      message.reply({ embeds: [embed] });
    } catch (error) {
      console.error('查询用户信息时出错:', error);
      message.reply('查询用户信息时发生错误，请稍后再试。');
    }
  }
};