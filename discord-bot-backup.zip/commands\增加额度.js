const { SlashCommandBuilder } = require('@discordjs/builders');
const { User } = require('../models');
const config = require('../config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('增加额度')
    .setDescription('当余额低于100$时，为自己增加200$配额'),
    
  async execute(interaction) {
    try {
      const discordId = interaction.user.id;
      
      // 查找用户 - 使用lean()获取普通JS对象
      const user = await User.findOne({ discordId }).lean();
      
      if (!user) {
        return interaction.reply({
          content: '您尚未绑定ID，请联系管理员进行绑定。',
          ephemeral: true
        });
      }
      
      // 获取用户ID以便后续更新
      const userId = user.userId;
      
      // 获取配额常量
      const minQuota = config.quota.minQuotaDollars * config.quota.dollarsToQuota; // 50,000,000
      const addQuota = config.quota.addQuotaDollars * config.quota.dollarsToQuota; // 100,000,000
      
      // 创建辅助函数转换为美元格式
      const formatQuotaAsDollars = (quota) => `$${(quota / config.quota.dollarsToQuota).toFixed(2)}`;
      
      // 计算剩余配额(使用原始配额单位)
      const remainingQuota = user.quota - user.usedQuota;
      
      // 检查是否需要增加配额(直接比较配额单位)
      if (remainingQuota >= minQuota) {
        return interaction.reply({
          content: `您当前剩余配额为 ${formatQuotaAsDollars(remainingQuota)}，高于 ${formatQuotaAsDollars(minQuota)}，无需增加配额。`,
          ephemeral: true
        });
      }
      
      // 记录原始配额
      const originalQuota = user.quota;
      
      // 记录原始配额
      const originalQuota = user.quota;
      
      // 创建历史记录条目
      const historyEntry = {
        timestamp: new Date(),
        action: 'manual_refill',
        amount: addQuota,
        reason: `用户手动补充配额（余额低于${formatQuotaAsDollars(minQuota)}）`,
        adminId: 'user_self'
      };
      
      // 使用findOneAndUpdate进行部分更新，只更新必要字段
      const updatedUser = await User.findOneAndUpdate(
        { userId },
        {
          $inc: { quota: addQuota },           // 增加配额
          $push: { quotaHistory: historyEntry },  // 添加历史记录
          $set: { lastQuotaUpdate: new Date() }   // 更新最后配额更新时间
        },
        { new: true, runValidators: true }     // 返回更新后的文档，运行验证器
      );
      
      if (!updatedUser) {
        return interaction.reply({
          content: '更新配额时发生错误，请联系管理员。',
          ephemeral: true
        });
      }
      
      // 计算新配额
      const newQuota = originalQuota + addQuota;
      
      // 回复用户(显示美元格式)
      await interaction.reply({
        content: `配额已成功增加!\n原配额: ${originalQuota} (${formatQuotaAsDollars(originalQuota)})\n新配额: ${newQuota} (${formatQuotaAsDollars(newQuota)})\n增加金额: ${addQuota} (${formatQuotaAsDollars(addQuota)})\n\n注意：系统在更新配额时会保留您的所有原始信息，包括用户名、分组和访问令牌等。`,
        ephemeral: true
      });
      
    } catch (error) {
      console.error('增加配额时出错:', error);
      await interaction.reply({
        content: '增加配额时发生错误，请稍后再试。',
        ephemeral: true
      });
    }
  }
};