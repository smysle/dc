const mongoose = require('mongoose');
const { Schema } = mongoose;

// 用户模型定义
const userSchema = new Schema({
  // Discord用户唯一ID
  discordId: {
    type: String,
    required: true,
    unique: true
  },
  
  // 用户名
  username: {
    type: String,
    required: true
  },
  
  // 绑定的ID
  boundId: {
    type: String,
    default: null
  },
  
  // 用户角色: 超级管理员、管理员、普通用户
  role: {
    type: String,
    enum: ['super-admin', 'admin', 'user'],
    default: 'user'
  },
  
  // 记录绑定ID的管理员
  boundBy: {
    type: String,
    default: null
  },
  
  // 绑定时间
  boundAt: {
    type: Date,
    default: null
  },
  
  // 配额相关
  quota: {
    type: Number,
    default: 0
  },
  
  // 已使用的配额
  usedQuota: {
    type: Number,
    default: 0
  },
  
  // 最后一次增加配额的时间
  lastQuotaUpdate: {
    type: Date,
    default: null
  },
  
  // 配额更新历史记录
  quotaHistory: [{
    amount: Number,
    timestamp: {
      type: Date,
      default: Date.now
    },
    reason: String
  }],
  
  // 创建时间
  createdAt: {
    type: Date,
    default: Date.now
  },
  
  // 最后更新时间
  updatedAt: {
    type: Date,
    default: Date.now
  }
});

// 创建索引以优化性能
userSchema.index({ discordId: 1 }, { unique: true });  // 为discordId创建唯一索引
userSchema.index({ boundId: 1 }, { sparse: true });    // 为boundId创建稀疏索引
userSchema.index({ username: 1 });                     // 为username创建索引
userSchema.index({ role: 1 });                         // 为role创建索引
userSchema.index({ lastQuotaUpdate: 1 });              // 为上次配额更新时间创建索引
userSchema.index({ 'quotaHistory.timestamp': 1 });     // 为配额历史时间戳创建索引
userSchema.index({ createdAt: 1 });                    // 为创建时间创建索引

// 更新前自动更新updatedAt字段
userSchema.pre('save', function(next) {
  this.updatedAt = Date.now();
  next();
});

// 分页查询方法
userSchema.statics.findPaginated = async function(filter = {}, options = {}) {
  const page = options.page || 1;
  const limit = options.limit || 20;
  const skip = (page - 1) * limit;
  const sort = options.sort || { createdAt: -1 };

  const [data, total] = await Promise.all([
    this.find(filter).sort(sort).skip(skip).limit(limit),
    this.countDocuments(filter)
  ]);

  return {
    data,
    pagination: {
      page,
      limit,
      total,
      pages: Math.ceil(total / limit)
    }
  };
};

// 创建并导出模型
const User = mongoose.model('User', userSchema);
module.exports = User;