const { SlashCommandBuilder } = require('@discordjs/builders');
const { MessageActionRow, MessageSelectMenu } = require('discord.js');
const { User } = require('../models');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('菜单')
    .setDescription('显示操作菜单，可选择不同功能'),
    
  async execute(interaction) {
    try {
      const discordId = interaction.user.id;
      
      // 检查用户是否存在
      const user = await User.findOne({ discordId });
      
      if (!user) {
        return interaction.reply({
          content: '您尚未绑定ID，请联系管理员进行绑定。',
          ephemeral: true
        });
      }
      
      // 创建操作选择菜单
      const row = new MessageActionRow()
        .addComponents(
          new MessageSelectMenu()
            .setCustomId('quota_operations')
            .setPlaceholder('请选择要执行的操作')
            .addOptions([
              {
                label: '查询余额',
                description: '查看当前配额余额',
                value: 'check_balance',
                emoji: '💰'
              },
              {
                label: '增加额度',
                description: '当余额低于100$时增加200$',
                value: 'add_quota',
                emoji: '🔄'
              }
            ])
        );
      
      // 发送带选择菜单的消息
      await interaction.reply({
        content: '请选择您要执行的操作：',
        components: [row],
        ephemeral: true
      });
      
    } catch (error) {
      console.error('生成菜单时出错:', error);
      await interaction.reply({
        content: '生成菜单时发生错误，请稍后再试。',
        ephemeral: true
      });
    }
  }
};