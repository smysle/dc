# 安全更新用户配额指南

本文档介绍了在Discord机器人中安全更新用户配额的最佳实践，避免可能导致用户信息丢失的常见问题。

## 问题背景

在早期版本中，我们发现在更新用户配额时，有时会导致以下问题：

1. 用户名被清空
2. 用户名称被重置
3. 用户分组变为空值
4. 用户访问令牌(access_token)丢失
5. 其他用户属性被重置为默认值

这些问题主要是由于在更新用户配额时使用了`save()`方法保存整个文档，而没有正确处理所有字段导致的。

## 解决方案

我们采用了以下方法来解决这些问题：

### 1. 使用部分更新而非保存整个文档

```javascript
// 错误做法: 可能导致字段丢失
user.quota += addQuota;
await user.save();

// 正确做法: 只更新必要字段
await User.findOneAndUpdate(
  { userId },
  { 
    $inc: { quota: addQuota },
    $push: { quotaHistory: historyEntry },
    $set: { lastQuotaUpdate: new Date() }
  },
  { new: true, runValidators: true }
);
```

### 2. 使用专用的更新操作对象

我们创建了`quota-helper.js`工具文件，提供标准化的更新操作:

```javascript
const updateOp = createQuotaUpdateOp(addQuota, 'manual_refill', reason, adminId);
await User.findOneAndUpdate({ userId }, updateOp, { new: true });
```

### 3. 使用lean()查询避免Mongoose默认值覆盖

```javascript
// 使用lean()获取普通JS对象，避免Mongoose默认值覆盖
const user = await User.findOne({ userId }).lean();
```

## 修改的文件

我们更新了以下文件以实现安全的配额更新：

1. `utils/quota-manager.js` - 更新了`checkAndRefillQuota`和`updateUsedQuota`函数
2. `commands/增加额度.js` - 更新了手动增加配额的逻辑
3. `utils/interaction-handler.js` - 更新了按钮交互处理
4. `utils/quota-helper.js` - 新增辅助函数文件

## 注意事项

1. **永远不要直接使用save()方法保存用户文档** - 除非你确保保留了所有原始字段
2. **使用部分更新操作** - 只更新需要修改的字段
3. **在显示时正确转换配额格式** - 使用`formatQuotaAsDollars`函数
4. **使用lean()查询** - 避免Mongoose默认值覆盖

## 配额单位计算

配额计算遵循以下规则：

- $1 = 500,000配额单位
- 最小配额阈值 = $100 = 50,000,000配额单位
- 增加配额量 = $200 = 100,000,000配额单位

所有内部计算都使用原始配额单位，只在显示时转换为美元格式。

## 测试验证

每次配额更新后，建议随机抽查几个用户，确认以下信息：

1. 配额是否正确更新
2. 用户名是否保留
3. 用户分组是否保留
4. 访问令牌是否保留
5. 其他自定义属性是否保留

如果发现任何字段丢失，请立即回滚更改并联系开发团队。