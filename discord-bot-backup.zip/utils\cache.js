/**
 * 缓存工具
 * 用于减少数据库查询并提高响应速度
 */

// 内存缓存，当Redis不可用时使用
const memoryCache = {
  data: new Map(),
  ttls: new Map(),
  
  // 获取缓存项
  get(key) {
    // 检查是否过期
    const expiry = this.ttls.get(key);
    if (expiry && expiry < Date.now()) {
      this.del(key);
      return null;
    }
    return this.data.get(key);
  },
  
  // 设置缓存项
  set(key, value, ttl = 0) {
    this.data.set(key, value);
    if (ttl > 0) {
      this.ttls.set(key, Date.now() + ttl * 1000);
    }
  },
  
  // 删除缓存项
  del(key) {
    this.data.delete(key);
    this.ttls.delete(key);
  },
  
  // 清除所有缓存
  flush() {
    this.data.clear();
    this.ttls.clear();
  },
  
  // 清除匹配模式的缓存项
  delPattern(pattern) {
    const regex = new RegExp(pattern.replace('*', '.*'));
    for (const key of this.data.keys()) {
      if (regex.test(key)) {
        this.del(key);
      }
    }
  }
};

// 缓存客户端
let cacheClient = memoryCache;
let redisAvailable = false;

/**
 * 初始化缓存
 * @param {Object} options - 缓存选项
 * @param {boolean} options.useRedis - 是否使用Redis
 * @param {string} options.redisUrl - Redis连接URL
 * @returns {Promise<Object>} - 缓存客户端
 */
async function initCache(options = {}) {
  // 设置默认选项，在Docker环境中默认使用Redis
  const defaultOptions = {
    useRedis: process.env.NODE_ENV === 'production',
    redisUrl: process.env.REDIS_URL || 'redis://redis:6379'
  };
  
  // 合并选项
  const finalOptions = { ...defaultOptions, ...options };
  
  // 如果不使用Redis，使用内存缓存
  if (!finalOptions.useRedis) {
    console.log('使用内存缓存');
    return { client: memoryCache, available: true };
  }
  
  // 尝试初始化Redis
  try {
    const Redis = require('ioredis');
    const redis = new Redis(options.redisUrl || 'redis://localhost:6379');
    
    // 测试连接
    await redis.ping();
    console.log('Redis缓存已连接');
    
    // 创建Redis缓存接口
    cacheClient = {
      get: async (key) => {
        const value = await redis.get(key);
        return value ? JSON.parse(value) : null;
      },
      set: async (key, value, ttl = 0) => {
        const serialized = JSON.stringify(value);
        if (ttl > 0) {
          await redis.setex(key, ttl, serialized);
        } else {
          await redis.set(key, serialized);
        }
      },
      del: async (key) => {
        await redis.del(key);
      },
      flush: async () => {
        await redis.flushdb();
      },
      delPattern: async (pattern) => {
        const keys = await redis.keys(pattern);
        if (keys.length > 0) {
          await redis.del(...keys);
        }
      }
    };
    
    redisAvailable = true;
    return { client: cacheClient, available: true, isRedis: true };
  } catch (error) {
    console.warn('Redis连接失败，使用内存缓存:', error.message);
    return { client: memoryCache, available: true, error };
  }
}

/**
 * 获取缓存项
 * @param {string} key - 缓存键
 * @returns {Promise<any>} - 缓存值或null
 */
async function getCache(key) {
  try {
    return await cacheClient.get(key);
  } catch (error) {
    console.error(`获取缓存出错 [${key}]:`, error);
    return null;
  }
}

/**
 * 设置缓存项
 * @param {string} key - 缓存键
 * @param {any} value - 缓存值
 * @param {number} ttl - 生存时间(秒)
 * @returns {Promise<boolean>} - 是否成功
 */
async function setCache(key, value, ttl = 0) {
  try {
    await cacheClient.set(key, value, ttl);
    return true;
  } catch (error) {
    console.error(`设置缓存出错 [${key}]:`, error);
    return false;
  }
}

/**
 * 删除缓存项
 * @param {string} key - 缓存键
 * @returns {Promise<boolean>} - 是否成功
 */
async function delCache(key) {
  try {
    await cacheClient.del(key);
    return true;
  } catch (error) {
    console.error(`删除缓存出错 [${key}]:`, error);
    return false;
  }
}

/**
 * 清除所有缓存
 * @returns {Promise<boolean>} - 是否成功
 */
async function flushCache() {
  try {
    await cacheClient.flush();
    return true;
  } catch (error) {
    console.error('清除缓存出错:', error);
    return false;
  }
}

/**
 * 删除匹配模式的缓存项
 * @param {string} pattern - 匹配模式
 * @returns {Promise<boolean>} - 是否成功
 */
async function delCachePattern(pattern) {
  try {
    await cacheClient.delPattern(pattern);
    return true;
  } catch (error) {
    console.error(`删除缓存模式出错 [${pattern}]:`, error);
    return false;
  }
}

/**
 * 带缓存的数据获取
 * @param {string} key - 缓存键
 * @param {Function} dataFn - 获取数据的函数
 * @param {number} ttl - 生存时间(秒)
 * @returns {Promise<any>} - 数据
 */
async function getCachedData(key, dataFn, ttl = 300) {
  // 尝试从缓存获取
  const cached = await getCache(key);
  if (cached !== null) {
    return cached;
  }
  
  // 缓存未命中，调用数据函数
  const data = await dataFn();
  
  // 缓存结果
  if (data !== null && data !== undefined) {
    await setCache(key, data, ttl);
  }
  
  return data;
}

/**
 * 缓存中间件
 * @param {Object} options - 缓存选项
 * @returns {Function} - Express中间件
 */
function cacheMiddleware(options = {}) {
  const defaultOptions = {
    ttl: 60, // 默认缓存60秒
    methods: ['GET'], // 只缓存GET请求
    keyGenerator: (req) => req.originalUrl || req.url,
    shouldCache: (req) => {
      // 不缓存认证相关请求
      return !(req.path.includes('/login') || req.path.includes('/logout'));
    }
  };
  
  const opts = { ...defaultOptions, ...options };
  
  return async (req, res, next) => {
    // 检查是否应该缓存
    if (!opts.methods.includes(req.method) || !opts.shouldCache(req)) {
      return next();
    }
    
    // 生成缓存键
    const key = `cache:${opts.keyGenerator(req)}`;
    
    // 尝试从缓存获取
    const cached = await getCache(key);
    if (cached) {
      return res.json(cached);
    }
    
    // 缓存未命中，保存原始json方法
    const originalJson = res.json;
    
    // 重写json方法
    res.json = function(data) {
      // 恢复原始方法
      res.json = originalJson;
      
      // 缓存响应
      setCache(key, data, opts.ttl).catch(err => {
        console.error(`API缓存出错 [${key}]:`, err);
      });
      
      // 调用原始方法
      return originalJson.call(this, data);
    };
    
    next();
  };
}

module.exports = {
  initCache,
  getCache,
  setCache,
  delCache,
  flushCache,
  delCachePattern,
  getCachedData,
  cacheMiddleware,
  get client() {
    return cacheClient;
  },
  get redisAvailable() {
    return redisAvailable;
  }
};