const { EmbedBuilder } = require('discord.js');
const config = require('../config');

module.exports = {
  name: 'help',
  description: '显示可用命令列表',
  async execute(message, args) {
    // 检查用户的角色
    const member = message.member;
    const isSuperAdmin = member.roles.cache.some(role => role.name === config.roles.superAdmin);
    const isAdmin = isSuperAdmin || member.roles.cache.some(role => role.name === config.roles.admin);
    
    // 创建嵌入消息
    const embed = new EmbedBuilder()
      .setTitle('Discord Bot 帮助')
      .setColor('#0099ff')
      .setDescription('以下是可用的命令列表：')
      .addFields(
        { name: `${config.prefix}help`, value: '显示此帮助信息' },
        { name: `${config.prefix}ping`, value: '测试机器人是否在线' }
      );
    
    // 添加普通用户命令
    embed.addFields(
      { name: `${config.prefix}myid`, value: '查看你绑定的ID和配额信息' },
      { name: `${config.prefix}addquota`, value: `增加你的配额 (每${config.quota.updateCooldown/(1000*60*60)}小时一次，余额低于$${config.quota.minQuotaDollars}时)` }
    );
    
    // 添加管理员命令
    if (isAdmin) {
      embed.addFields(
        { name: `${config.prefix}bind <@用户> <ID>`, value: '绑定用户ID (仅限管理员)' },
        { name: `${config.prefix}unbind <@用户>`, value: '解绑用户ID (仅限管理员)' },
        { name: `${config.prefix}userinfo <@用户>`, value: '查看用户信息 (仅限管理员)' }
      );
    }
    
    // 添加超级管理员命令
    if (isSuperAdmin) {
      embed.addFields(
        { name: `${config.prefix}setadmin <@用户>`, value: '设置用户为管理员 (仅限超级管理员)' },
        { name: `${config.prefix}removeadmin <@用户>`, value: '移除用户的管理员权限 (仅限超级管理员)' }
      );
    }
    
    message.reply({ embeds: [embed] });
  }
};