/**
 * 并发控制工具
 * 用于防止多个用户同时操作时的数据一致性问题
 */

// 操作锁管理
const operationLocks = new Map();

/**
 * 使用互斥锁执行异步操作
 * @param {string} lockKey - 锁的唯一标识符
 * @param {Function} operation - 要执行的异步操作函数
 * @param {number} timeout - 锁超时时间（毫秒），默认5秒
 * @returns {Promise<any>} - 操作结果
 */
async function withMutex(lockKey, operation, timeout = 5000) {
  // 检查锁是否已存在
  if (operationLocks.has(lockKey)) {
    throw new Error(`操作被锁定，请稍后再试: ${lockKey}`);
  }
  
  // 创建锁
  const lock = { timestamp: Date.now() };
  operationLocks.set(lockKey, lock);
  
  // 设置锁超时自动释放
  const timeoutId = setTimeout(() => {
    if (operationLocks.get(lockKey) === lock) {
      operationLocks.delete(lockKey);
      console.warn(`锁自动释放 (超时): ${lockKey}`);
    }
  }, timeout);
  
  try {
    // 执行操作
    const result = await operation();
    return result;
  } finally {
    // 清除超时计时器
    clearTimeout(timeoutId);
    
    // 释放锁
    if (operationLocks.get(lockKey) === lock) {
      operationLocks.delete(lockKey);
    }
  }
}

/**
 * 为用户配额更新创建锁键
 * @param {string} userId - 用户ID
 * @returns {string} - 锁键
 */
function getQuotaLockKey(userId) {
  return `quota:${userId}`;
}

/**
 * 为系统设置更新创建锁键
 * @param {string} category - 设置类别
 * @returns {string} - 锁键
 */
function getSettingsLockKey(category) {
  return `settings:${category}`;
}

/**
 * 为用户绑定操作创建锁键
 * @param {string} userId - 用户ID
 * @returns {string} - 锁键
 */
function getBindLockKey(userId) {
  return `bind:${userId}`;
}

/**
 * 带有乐观锁的文档更新
 * @param {Model} Model - Mongoose模型
 * @param {Object} filter - 查询过滤条件
 * @param {Object} update - 更新操作
 * @param {number} maxRetries - 最大重试次数
 * @returns {Promise<Document>} - 更新后的文档
 */
async function updateWithOptimisticLock(Model, filter, update, maxRetries = 3) {
  let retries = 0;
  
  while (retries < maxRetries) {
    // 获取当前文档版本
    const doc = await Model.findOne(filter);
    if (!doc) {
      throw new Error('找不到要更新的文档');
    }
    
    // 添加版本检查到更新条件
    const versionFilter = { 
      ...filter,
      updatedAt: doc.updatedAt 
    };
    
    // 执行更新
    const result = await Model.findOneAndUpdate(
      versionFilter,
      { ...update, updatedAt: new Date() },
      { new: true }
    );
    
    // 如果更新成功
    if (result) {
      return result;
    }
    
    // 更新失败，尝试重试
    retries++;
    
    if (retries >= maxRetries) {
      throw new Error('并发更新冲突，请重试操作');
    }
    
    // 等待随机时间后重试（避免活锁）
    await new Promise(resolve => setTimeout(resolve, 50 + Math.random() * 100));
  }
}

module.exports = {
  withMutex,
  getQuotaLockKey,
  getSettingsLockKey,
  getBindLockKey,
  updateWithOptimisticLock
};