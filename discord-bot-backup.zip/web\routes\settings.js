const express = require('express');
const router = express.Router();
const { Setting } = require('../../models');
const config = require('../../config');
const { withMutex, getSettingsLockKey } = require('../../utils/concurrency');

// 中间件：检查是否已登录
const isAuthenticated = (req, res, next) => {
  if (req.session.user) {
    return next();
  }
  res.redirect('/login');
};

// 中间件：检查是否为超级管理员
const isSuperAdmin = (req, res, next) => {
  if (req.session.user && req.session.user.isSuperAdmin) {
    return next();
  }
  res.status(403).render('error', {
    title: '访问被拒绝',
    message: '您没有权限访问此页面',
    error: { status: 403 }
  });
};

// 系统状态信息
router.get('/status', isAuthenticated, (req, res) => {
  const status = global.systemStatus || {
    databaseConnected: false,
    botRunning: false,
    webServerRunning: true,
    needsConfiguration: true
  };
  
  // 获取Bot信息
  let botInfo = null;
  if (global.botUser) {
    botInfo = {
      username: global.botUser.username,
      id: global.botUser.id,
      avatar: global.botUser.displayAvatarURL({ dynamic: true })
    };
  }
  
  // 获取服务器信息
  let guildInfo = null;
  if (global.discordGuild) {
    guildInfo = {
      name: global.discordGuild.name,
      id: global.discordGuild.id,
      memberCount: global.discordGuild.memberCount,
      icon: global.discordGuild.iconURL({ dynamic: true })
    };
  }
  
  res.json({
    success: true,
    data: {
      status,
      botInfo,
      guildInfo,
      uptime: process.uptime(),
      nodeVersion: process.version
    }
  });
});

// 系统设置页面
router.get('/', isAuthenticated, isSuperAdmin, async (req, res) => {
  try {
    // 获取按类别分组的设置
    const discordSettings = await Setting.getSettingsByCategory('discord', true);
    const quotaSettings = await Setting.getSettingsByCategory('quota', true);
    const webSettings = await Setting.getSettingsByCategory('web', true);
    const generalSettings = await Setting.getSettingsByCategory('general', true);
    
    // 获取系统状态
    const status = global.systemStatus || {
      databaseConnected: false,
      botRunning: false,
      webServerRunning: true,
      needsConfiguration: true
    };
    
    // 获取Bot信息
    let botInfo = null;
    if (global.botUser) {
      botInfo = {
        username: global.botUser.username,
        id: global.botUser.id,
        avatar: global.botUser.displayAvatarURL({ dynamic: true })
      };
    }
    
    res.render('settings/index', {
      title: '系统设置',
      user: req.session.user,
      settings: {
        discord: discordSettings,
        quota: quotaSettings,
        web: webSettings,
        general: generalSettings
      },
      status,
      botInfo,
      success: req.query.success,
      error: req.query.error
    });
  } catch (error) {
    console.error('获取系统设置时出错:', error);
    res.status(500).render('error', {
      title: '错误',
      message: '获取系统设置时发生错误',
      error
    });
  }
});

// 设置向导页面
router.get('/wizard', isAuthenticated, isSuperAdmin, async (req, res) => {
  try {
    // 获取Discord设置
    const discordSettings = await Setting.getSettingsByCategory('discord', true);
    
    res.render('settings/wizard', {
      title: '系统设置向导',
      user: req.session.user,
      discordSettings,
      step: req.query.step || '1',
      success: req.query.success,
      error: req.query.error
    });
  } catch (error) {
    console.error('获取设置向导时出错:', error);
    res.status(500).render('error', {
      title: '错误',
      message: '获取设置向导时发生错误',
      error
    });
  }
});

// 保存设置
router.post('/update', isAuthenticated, isSuperAdmin, async (req, res) => {
  try {
    const { category, settings } = req.body;
    
    if (!category || !settings) {
      return res.redirect('/settings?error=无效的设置数据');
    }
    
    // 使用互斥锁确保同一类别的设置不会并发更新
    await withMutex(getSettingsLockKey(category), async () => {
      // 根据类别筛选设置
      const allowedSettings = await Setting.getSettingsByCategory(category, true);
      const allowedKeys = allowedSettings.map(s => s.key);
      
      // 过滤出合法的设置
      const validSettings = {};
      for (const [key, value] of Object.entries(settings)) {
        if (allowedKeys.includes(key)) {
          validSettings[key] = value;
        }
      }
      
      // 更新设置
      await Setting.updateMultipleValues(validSettings, req.session.user.username);
      
      // 重新加载设置到内存
      const { loadSettings } = require('../../models');
      await loadSettings();
      
      // 根据情况重启Bot
      if (category === 'discord' && global.systemStatus.botRunning) {
        try {
          // 关闭现有连接
          if (global.discordClient) {
            global.discordClient.destroy();
          }
          
          // 重新启动Bot
          const startBot = async () => {
            try {
              await global.discordClient.login(config.bot.token);
              global.systemStatus.botRunning = true;
              return true;
            } catch (error) {
              console.error('重启Bot失败:', error);
              global.systemStatus.botRunning = false;
              return false;
            }
          };
          
          await startBot();
        } catch (botError) {
          console.error('重启Bot时出错:', botError);
        }
      }
    });
    
    // 重定向回设置页面
    if (req.query.wizard === 'true') {
      const nextStep = parseInt(req.query.step || '1') + 1;
      return res.redirect(`/settings/wizard?step=${nextStep}&success=设置已保存`);
    } else {
      return res.redirect('/settings?success=设置已成功更新');
    }
  } catch (error) {
    console.error('更新设置时出错:', error);
    
    let errorMessage = '更新设置时发生错误';
    if (error.message.includes('操作被锁定')) {
      errorMessage = '另一个管理员正在更新相同的设置，请稍后再试';
    }
    
    res.redirect(`/settings?error=${encodeURIComponent(errorMessage)}`);
  }
});

// 一键测试设置
router.post('/test-bot', isAuthenticated, isSuperAdmin, async (req, res) => {
  try {
    // 获取Discord设置
    const botToken = await Setting.getValue('bot_token');
    
    if (!botToken) {
      return res.json({
        success: false,
        message: '未配置Bot Token'
      });
    }
    
    // 尝试重启Bot
    try {
      // 关闭现有连接
      if (global.discordClient) {
        global.discordClient.destroy();
      }
      
      // 重新登录
      await global.discordClient.login(botToken);
      global.systemStatus.botRunning = true;
      
      return res.json({
        success: true,
        message: 'Bot连接成功',
        data: {
          username: global.discordClient.user.username,
          id: global.discordClient.user.id
        }
      });
    } catch (botError) {
      global.systemStatus.botRunning = false;
      return res.json({
        success: false,
        message: `Bot连接失败: ${botError.message}`
      });
    }
  } catch (error) {
    console.error('测试Bot设置时出错:', error);
    res.status(500).json({
      success: false,
      message: '测试Bot设置时发生错误'
    });
  }
});

module.exports = router;