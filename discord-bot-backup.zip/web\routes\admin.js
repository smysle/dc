const express = require('express');
const router = express.Router();
const { Admin, User } = require('../../models');

// 中间件：检查是否已登录
const isAuthenticated = (req, res, next) => {
  if (req.session.user) {
    return next();
  }
  res.redirect('/login');
};

// 中间件：检查是否为超级管理员
const isSuperAdmin = (req, res, next) => {
  if (req.session.user && req.session.user.isSuperAdmin) {
    return next();
  }
  res.status(403).render('error', {
    title: '访问被拒绝',
    message: '您没有权限访问此页面',
    error: { status: 403 }
  });
};

// 管理员设置页面 - 需要超级管理员权限
router.get('/settings', isAuthenticated, isSuperAdmin, async (req, res) => {
  try {
    // 获取所有管理员
    const admins = await Admin.find().sort({ createdAt: -1 });
    
    res.render('admin/settings', {
      title: '管理员设置',
      user: req.session.user,
      admins,
      error: req.query.error,
      success: req.query.success
    });
  } catch (error) {
    console.error('加载管理员设置页面错误:', error);
    res.status(500).render('error', {
      title: '错误',
      message: '加载管理员设置页面时发生错误',
      error
    });
  }
});

// 添加新管理员 - 需要超级管理员权限
router.post('/add', isAuthenticated, isSuperAdmin, async (req, res) => {
  try {
    const { username, password, isSuperAdmin } = req.body;
    
    if (!username || !password) {
      return res.redirect('/admin/settings?error=请提供用户名和密码');
    }
    
    // 检查用户名是否已存在
    const existingAdmin = await Admin.findOne({ username });
    if (existingAdmin) {
      return res.redirect('/admin/settings?error=用户名已存在');
    }
    
    // 创建新管理员
    const admin = new Admin({
      username,
      isSuperAdmin: isSuperAdmin === 'on'
    });
    
    admin.setPassword(password);
    await admin.save();
    
    res.redirect('/admin/settings?success=管理员添加成功');
  } catch (error) {
    console.error('添加管理员错误:', error);
    res.redirect(`/admin/settings?error=${encodeURIComponent('添加管理员时发生错误')}`);
  }
});

// 删除管理员 - 需要超级管理员权限
router.post('/delete/:id', isAuthenticated, isSuperAdmin, async (req, res) => {
  try {
    const admin = await Admin.findById(req.params.id);
    
    if (!admin) {
      return res.redirect('/admin/settings?error=管理员不存在');
    }
    
    // 防止删除自己
    if (admin._id.toString() === req.session.user.id) {
      return res.redirect('/admin/settings?error=不能删除自己的账户');
    }
    
    await Admin.findByIdAndDelete(req.params.id);
    res.redirect('/admin/settings?success=管理员删除成功');
  } catch (error) {
    console.error('删除管理员错误:', error);
    res.redirect(`/admin/settings?error=${encodeURIComponent('删除管理员时发生错误')}`);
  }
});

// 修改密码页面
router.get('/change-password', isAuthenticated, (req, res) => {
  res.render('admin/change-password', {
    title: '修改密码',
    user: req.session.user,
    error: req.query.error,
    success: req.query.success
  });
});

// 处理修改密码请求
router.post('/change-password', isAuthenticated, async (req, res) => {
  try {
    const { currentPassword, newPassword, confirmPassword } = req.body;
    
    if (!currentPassword || !newPassword || !confirmPassword) {
      return res.redirect('/admin/change-password?error=所有字段都是必填的');
    }
    
    if (newPassword !== confirmPassword) {
      return res.redirect('/admin/change-password?error=新密码和确认密码不匹配');
    }
    
    // 获取当前管理员
    const admin = await Admin.findById(req.session.user.id);
    if (!admin) {
      req.session.destroy();
      return res.redirect('/login?error=会话已过期，请重新登录');
    }
    
    // 验证当前密码
    if (!admin.validatePassword(currentPassword)) {
      return res.redirect('/admin/change-password?error=当前密码不正确');
    }
    
    // 更新密码
    admin.setPassword(newPassword);
    await admin.save();
    
    res.redirect('/admin/change-password?success=密码修改成功');
  } catch (error) {
    console.error('修改密码错误:', error);
    res.redirect(`/admin/change-password?error=${encodeURIComponent('修改密码时发生错误')}`);
  }
});

// 用户管理页面
router.get('/users', isAuthenticated, async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = 20;
    const skip = (page - 1) * limit;
    
    // 过滤条件
    const filter = {};
    if (req.query.bound === 'true') {
      filter.boundId = { $ne: null };
    } else if (req.query.bound === 'false') {
      filter.boundId = null;
    }
    
    if (req.query.search) {
      const search = req.query.search;
      filter.$or = [
        { username: { $regex: search, $options: 'i' } },
        { boundId: { $regex: search, $options: 'i' } },
        { discordId: { $regex: search, $options: 'i' } }
      ];
    }
    
    // 获取用户数据
    const users = await User.find(filter)
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(limit);
    
    // 获取总数
    const total = await User.countDocuments(filter);
    
    res.render('admin/users', {
      title: '用户管理',
      user: req.session.user,
      users,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit)
      },
      query: req.query,
      success: req.query.success,
      error: req.query.error
    });
  } catch (error) {
    console.error('加载用户管理页面错误:', error);
    res.status(500).render('error', {
      title: '错误',
      message: '加载用户管理页面时发生错误',
      error
    });
  }
});

// 用户详情页面
router.get('/users/:id', isAuthenticated, async (req, res) => {
  try {
    const user = await User.findOne({ 
      $or: [
        { _id: req.params.id },
        { discordId: req.params.id },
        { boundId: req.params.id }
      ]
    });
    
    if (!user) {
      return res.status(404).render('error', {
        title: '用户未找到',
        message: '找不到指定的用户',
        error: { status: 404 }
      });
    }
    
    res.render('admin/user-detail', {
      title: '用户详情',
      user: req.session.user,
      discordUser: user,
      success: req.query.success,
      error: req.query.error
    });
  } catch (error) {
    console.error('加载用户详情页面错误:', error);
    res.status(500).render('error', {
      title: '错误',
      message: '加载用户详情页面时发生错误',
      error
    });
  }
});

module.exports = router;