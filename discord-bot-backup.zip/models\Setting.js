const mongoose = require('mongoose');
const { Schema } = mongoose;

// 系统设置模型定义
const settingSchema = new Schema({
  // 设置键
  key: {
    type: String,
    required: true,
    unique: true
  },
  
  // 设置值
  value: {
    type: Schema.Types.Mixed,
    required: true
  },
  
  // 设置描述
  description: {
    type: String,
    default: ''
  },
  
  // 设置类别
  category: {
    type: String,
    enum: ['discord', 'database', 'web', 'quota', 'general'],
    default: 'general'
  },
  
  // 是否敏感信息(如密码、token)
  isSecret: {
    type: Boolean,
    default: false
  },
  
  // 最后更新时间
  updatedAt: {
    type: Date,
    default: Date.now
  },
  
  // 最后更新者
  updatedBy: {
    type: String,
    default: 'system'
  }
});

// 预设系统默认设置的静态方法
settingSchema.statics.initDefaultSettings = async function() {
  // 检查是否已有设置
  const count = await this.countDocuments();
  if (count > 0) {
    console.log('系统设置已存在，跳过初始化');
    return;
  }
  
  // 默认设置列表
  const defaultSettings = [
    // Discord Bot 设置
    {
      key: 'bot_token',
      value: '',
      description: 'Discord Bot令牌',
      category: 'discord',
      isSecret: true
    },
    {
      key: 'client_id',
      value: '',
      description: 'Discord应用客户端ID',
      category: 'discord',
      isSecret: false
    },
    {
      key: 'guild_id',
      value: '',
      description: 'Discord服务器ID',
      category: 'discord',
      isSecret: false
    },
    {
      key: 'prefix',
      value: '!',
      description: '命令前缀',
      category: 'discord',
      isSecret: false
    },
    
    // 配额设置
    {
      key: 'dollars_to_quota',
      value: 500000,
      description: '配额兑换率: $1 = ? 配额',
      category: 'quota',
      isSecret: false
    },
    {
      key: 'min_quota_dollars',
      value: 100,
      description: '最小配额阈值 ($)',
      category: 'quota',
      isSecret: false
    },
    {
      key: 'add_quota_dollars',
      value: 200,
      description: '每次增加配额 ($)',
      category: 'quota',
      isSecret: false
    },
    {
      key: 'update_cooldown',
      value: 6 * 60 * 60 * 1000,
      description: '配额更新冷却时间 (毫秒)',
      category: 'quota',
      isSecret: false
    },
    
    // Web设置
    {
      key: 'port',
      value: 3000,
      description: 'Web服务器端口',
      category: 'web',
      isSecret: false
    },
    {
      key: 'session_secret',
      value: 'default-session-secret-please-change',
      description: '会话密钥',
      category: 'web',
      isSecret: true
    },
    
    // 角色设置
    {
      key: 'super_admin_role',
      value: 'super-admin',
      description: '超级管理员角色名称',
      category: 'discord',
      isSecret: false
    },
    {
      key: 'admin_role',
      value: 'admin',
      description: '管理员角色名称',
      category: 'discord',
      isSecret: false
    }
  ];
  
  // 批量插入默认设置
  try {
    await this.insertMany(defaultSettings);
    console.log('系统默认设置初始化完成');
  } catch (error) {
    console.error('初始化系统设置失败:', error);
    throw error;
  }
};

// 获取所有设置，并以key-value对象形式返回
settingSchema.statics.getAllSettings = async function(includeSecrets = false) {
  const query = includeSecrets ? {} : { isSecret: false };
  const settings = await this.find(query);
  
  // 转换为key-value对象
  const settingsObject = {};
  settings.forEach(setting => {
    settingsObject[setting.key] = setting.value;
  });
  
  return settingsObject;
};

// 按类别获取设置
settingSchema.statics.getSettingsByCategory = async function(category, includeSecrets = false) {
  const query = { category };
  if (!includeSecrets) {
    query.isSecret = false;
  }
  
  return await this.find(query);
};

// 获取单个设置值
settingSchema.statics.getValue = async function(key, defaultValue = null) {
  const setting = await this.findOne({ key });
  return setting ? setting.value : defaultValue;
};

// 更新设置值
settingSchema.statics.updateValue = async function(key, value, updatedBy = 'system') {
  const setting = await this.findOne({ key });
  
  if (!setting) {
    throw new Error(`设置 ${key} 不存在`);
  }
  
  setting.value = value;
  setting.updatedAt = new Date();
  setting.updatedBy = updatedBy;
  
  await setting.save();
  return setting;
};

// 批量更新设置
settingSchema.statics.updateMultipleValues = async function(settings, updatedBy = 'system') {
  const operations = [];
  
  for (const [key, value] of Object.entries(settings)) {
    operations.push(this.updateValue(key, value, updatedBy));
  }
  
  await Promise.all(operations);
  return await this.getAllSettings(true);
};

// 创建并导出模型
const Setting = mongoose.model('Setting', settingSchema);
module.exports = Setting;