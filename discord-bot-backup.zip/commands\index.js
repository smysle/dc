const fs = require('fs');
const path = require('path');
const config = require('../config');

// 创建一个新的命令集合
const commands = new Map();

// 获取所有命令文件
const commandFiles = fs.readdirSync(__dirname)
  .filter(file => file.endsWith('.js') && file !== 'index.js');

// 加载所有命令
for (const file of commandFiles) {
  const command = require(path.join(__dirname, file));
  // 将命令添加到集合中
  commands.set(command.name, command);
}

// 命令处理器
const handleCommand = async (message) => {
  // 忽略机器人消息和不以前缀开头的消息
  if (message.author.bot || !message.content.startsWith(config.prefix)) return;

  // 解析命令和参数
  const args = message.content.slice(config.prefix.length).trim().split(/ +/);
  const commandName = args.shift().toLowerCase();

  // 查找命令
  const command = commands.get(commandName);
  if (!command) return;

  try {
    // 执行命令
    await command.execute(message, args);
  } catch (error) {
    console.error(`执行命令 ${commandName} 时出错:`, error);
    message.reply('执行命令时发生错误，请稍后再试。');
  }
};

module.exports = {
  commands,
  handleCommand
};