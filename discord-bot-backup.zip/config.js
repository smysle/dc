require('dotenv').config();

module.exports = {
  // Discord Bot配置
  bot: {
    token: process.env.BOT_TOKEN || 'your_discord_bot_token',
    clientId: process.env.CLIENT_ID || 'your_client_id',
    guildId: process.env.GUILD_ID || 'your_guild_id'
  },
  
  // 数据库配置
  database: {
    uri: process.env.MONGODB_URI || 'mongodb://localhost:27017/discord-bot'
  },

  // 用户角色配置
  roles: {
    superAdmin: 'super-admin',  // 超级管理员角色名称
    admin: 'admin',             // 管理员角色名称
    user: 'user'                // 普通用户角色名称
  },

  // 命令前缀
  prefix: '!',
  
  // 配额设置
  quota: {
    // 配额兑换率: $1 = 500,000 配额
    dollarsToQuota: 500000,
    
    // 最小配额阈值 ($100)
    minQuotaDollars: 100,
    
    // 每次增加配额 ($200)
    addQuotaDollars: 200,
    
    // 配额更新冷却时间 (6小时，单位：毫秒)
    updateCooldown: 6 * 60 * 60 * 1000
  },
  
  // Web界面配置
  web: {
    port: process.env.PORT || 3000,
    sessionSecret: process.env.SESSION_SECRET || 'your-session-secret',
    defaultAdmin: {
      username: 'admin',
      password: 'admin'
    }
  }
};