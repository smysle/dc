/**
 * 选择菜单处理器
 * 处理Discord选择菜单交互
 */
const { User } = require('../models');
const { MessageActionRow, MessageSelectMenu, MessageButton } = require('discord.js');

/**
 * 处理选择菜单交互
 * @param {Object} interaction - Discord交互对象
 */
async function handleSelectMenuInteraction(interaction) {
  try {
    // 获取选择菜单的自定义ID
    const customId = interaction.customId;
    
    // 处理不同的选择菜单
    if (customId === 'select_user_to_view') {
      // 获取选择的值（用户ID）
      const selectedUserId = interaction.values[0];
      
      // 查找用户
      const user = await User.findOne({ discordId: selectedUserId });
      
      if (!user) {
        return interaction.update({
          content: '无法找到所选用户的信息。',
          components: []
        });
      }
      
      // 构建用户信息
      const userInfo = `**已选择用户信息**\n` +
                       `用户名: ${user.username}\n` +
                       `用户ID: ${user.userId || '未绑定'}\n` +
                       `绑定状态: ${user.boundId ? '已绑定' : '未绑定'}\n` +
                       `角色: ${user.role === 'admin' ? '管理员' : '普通用户'}\n` +
                       `总配额: $${user.quota.toFixed(2)}\n` +
                       `已使用: $${user.usedQuota.toFixed(2)}\n` +
                       `剩余: $${(user.quota - user.usedQuota).toFixed(2)}`;
      
      // 创建管理按钮
      let components = [];
      
      // 管理员操作选择菜单
      const adminActions = new MessageActionRow()
        .addComponents(
          new MessageSelectMenu()
            .setCustomId(`admin_actions_${user.discordId}`)
            .setPlaceholder('选择管理操作')
            .addOptions([
              {
                label: '增加配额',
                description: '增加200$配额',
                value: `add_quota_${user.discordId}`,
                emoji: '💰'
              },
              {
                label: '重置配额',
                description: '重置已使用配额为0',
                value: `reset_used_quota_${user.discordId}`,
                emoji: '🔄'
              }
            ])
        );
      
      components.push(adminActions);
      
      // 增加额度按钮（如果余额低于100$）
      if (user.quota - user.usedQuota < 100) {
        components.push(
          new MessageActionRow()
            .addComponents(
              new MessageButton()
                .setCustomId(`增加额度_${user.userId}`)
                .setLabel('增加额度 (+$200)')
                .setStyle('PRIMARY')
            )
        );
      }
      
      // 更新回复
      await interaction.update({
        content: userInfo,
        components: components
      });
    }
    
    // 处理配额操作选择菜单
    else if (customId === 'quota_operations') {
      const selectedOperation = interaction.values[0];
      const discordId = interaction.user.id;
      
      // 查找用户
      const user = await User.findOne({ discordId });
      
      if (!user) {
        return interaction.update({
          content: '您尚未绑定ID，请联系管理员进行绑定。',
          components: []
        });
      }
      
      // 根据选择的操作执行不同功能
      switch (selectedOperation) {
        case 'check_balance':
          // 格式化余额显示
          const formattedQuota = user.quota.toFixed(2);
          const formattedUsedQuota = user.usedQuota.toFixed(2);
          const formattedRemaining = (user.quota - user.usedQuota).toFixed(2);
          
          // 构建回复消息
          let replyContent = `**余额信息**\n用户ID: ${user.userId}\n总余额: $${formattedQuota}\n已使用: $${formattedUsedQuota}\n剩余: $${formattedRemaining}`;
          
          // 根据余额状态准备不同的按钮
          let row;
          
          // 余额低于100$，显示"增加额度"按钮
          if (user.quota - user.usedQuota < 100) {
            row = new MessageActionRow()
              .addComponents(
                new MessageButton()
                  .setCustomId('增加额度_' + user.userId)
                  .setLabel('增加额度 (+$200)')
                  .setStyle('PRIMARY')
              );
            
            // 添加提示信息
            replyContent += `\n\n**提示**: 您的余额低于 $100，可以点击下方按钮增加 $200 配额。`;
          } else {
            row = new MessageActionRow()
              .addComponents(
                new MessageButton()
                  .setCustomId('refresh_balance')
                  .setLabel('刷新余额')
                  .setStyle('SECONDARY')
              );
            
            replyContent += '\n\n您的余额充足，无需增加配额。';
          }
          
          // 更新回复
          await interaction.update({
            content: replyContent,
            components: [row]
          });
          break;
          
        case 'add_quota':
          // 检查是否需要增加配额
          const remainingQuota = user.quota - user.usedQuota;
          
          if (remainingQuota >= 100) {
            await interaction.update({
              content: `您当前剩余配额为 $${remainingQuota.toFixed(2)}，高于 $100，无需增加配额。`,
              components: []
            });
            return;
          }
          
          // 记录原始配额
          const originalQuota = user.quota;
          
          // 增加配额
          user.quota += 200;
          
          // 添加配额历史记录
          user.quotaHistory.push({
            timestamp: new Date(),
            action: 'menu_refill',
            amount: 200,
            reason: '用户通过菜单补充配额（余额低于$100）',
            adminId: 'user_self'
          });
          
          // 保存用户
          await user.save();
          
          // 更新回复
          await interaction.update({
            content: `配额已成功增加!\n原余额: $${originalQuota.toFixed(2)}\n新余额: $${user.quota.toFixed(2)}\n增加金额: $200.00`,
            components: []
          });
          break;
          
        default:
          await interaction.update({
            content: '未知的操作。',
            components: []
          });
      }
    }
    
    // 处理管理员操作选择菜单
    else if (customId.startsWith('admin_actions_')) {
      const selectedValue = interaction.values[0];
      
      // 解析选择的操作和用户ID
      if (selectedValue.startsWith('add_quota_')) {
        const discordId = selectedValue.replace('add_quota_', '');
        
        // 查找用户
        const user = await User.findOne({ discordId });
        
        if (!user) {
          return interaction.update({
            content: '找不到用户信息。',
            components: []
          });
        }
        
        // 记录原始配额
        const originalQuota = user.quota;
        
        // 增加配额
        user.quota += 200;
        
        // 添加配额历史记录
        user.quotaHistory.push({
          timestamp: new Date(),
          action: 'admin_add',
          amount: 200,
          reason: '管理员通过菜单增加配额',
          adminId: interaction.user.id
        });
        
        // 保存用户
        await user.save();
        
        // 更新回复
        await interaction.update({
          content: `成功为 ${user.username} 增加配额!\n原余额: $${originalQuota.toFixed(2)}\n新余额: $${user.quota.toFixed(2)}\n增加金额: $200.00`,
          components: []
        });
      }
      // 重置已使用配额
      else if (selectedValue.startsWith('reset_used_quota_')) {
        const discordId = selectedValue.replace('reset_used_quota_', '');
        
        // 查找用户
        const user = await User.findOne({ discordId });
        
        if (!user) {
          return interaction.update({
            content: '找不到用户信息。',
            components: []
          });
        }
        
        // 记录原始使用配额
        const originalUsedQuota = user.usedQuota;
        
        // 重置已使用配额
        user.usedQuota = 0;
        
        // 添加配额历史记录
        user.quotaHistory.push({
          timestamp: new Date(),
          action: 'admin_reset',
          amount: -originalUsedQuota,
          reason: '管理员重置已使用配额',
          adminId: interaction.user.id
        });
        
        // 保存用户
        await user.save();
        
        // 更新回复
        await interaction.update({
          content: `成功为 ${user.username} 重置已使用配额!\n原已使用: $${originalUsedQuota.toFixed(2)}\n现已使用: $0.00\n当前总额: $${user.quota.toFixed(2)}`,
          components: []
        });
      }
    }
    
  } catch (error) {
    console.error('处理选择菜单交互时出错:', error);
    // 尝试回复错误
    try {
      await interaction.update({
        content: '处理请求时发生错误，请稍后再试。',
        components: []
      });
    } catch (updateError) {
      console.error('无法更新交互:', updateError);
    }
  }
}

module.exports = {
  handleSelectMenuInteraction
};