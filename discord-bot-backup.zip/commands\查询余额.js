const { SlashCommandBuilder } = require('@discordjs/builders');
const { User } = require('../models');
const { MessageActionRow, MessageButton } = require('discord.js');
const config = require('../config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('查询余额')
    .setDescription('查询自己的绑定ID余额'),
    
  async execute(interaction) {
    try {
      const discordId = interaction.user.id;
      
      // 查找用户
      const user = await User.findOne({ discordId });
      
      if (!user) {
        return interaction.reply({
          content: '您尚未绑定ID，请联系管理员进行绑定。',
          ephemeral: true
        });
      }
      
      // 获取配额常量
      const minQuota = config.quota.minQuotaDollars * config.quota.dollarsToQuota; // 50,000,000
      const addQuota = config.quota.addQuotaDollars * config.quota.dollarsToQuota; // 100,000,000
      
      // 创建辅助函数转换为美元格式
      const formatQuotaAsDollars = (quota) => `$${(quota / config.quota.dollarsToQuota).toFixed(2)}`;
      
      // 计算剩余配额(使用原始配额单位)
      const remainingQuota = user.quota - user.usedQuota;
      
      // 构建回复消息(同时显示原始配额和美元格式)
      let replyContent = `**余额信息**\n用户ID: ${user.userId}\n` +
                         `总配额: ${user.quota} (${formatQuotaAsDollars(user.quota)})\n` +
                         `已使用: ${user.usedQuota} (${formatQuotaAsDollars(user.usedQuota)})\n` +
                         `剩余: ${remainingQuota} (${formatQuotaAsDollars(remainingQuota)})`;
      
      // 根据余额状态准备不同的按钮
      let row;
      
      // 余额低于阈值(50,000,000)，显示"增加额度"按钮
      if (remainingQuota < minQuota) {
        row = new MessageActionRow()
          .addComponents(
            new MessageButton()
              .setCustomId('增加额度_' + user.userId)
              .setLabel(`增加额度 (${formatQuotaAsDollars(addQuota)})`)
              .setStyle('PRIMARY')
          );
        
        // 添加提示信息
        replyContent += `\n\n**提示**: 您的余额低于 ${formatQuotaAsDollars(minQuota)}，可以点击下方按钮增加 ${formatQuotaAsDollars(addQuota)} 配额。`;
      } else {
        row = new MessageActionRow()
          .addComponents(
            new MessageButton()
              .setCustomId('refresh_balance')
              .setLabel('刷新余额')
              .setStyle('SECONDARY')
          );
        
        replyContent += '\n\n您的余额充足，无需增加配额。';
      }
      
      // 发送带按钮的余额信息
      await interaction.reply({
        content: replyContent,
        components: [row],
        ephemeral: true // 只有用户自己可见
      });
      
    } catch (error) {
      console.error('查询余额时出错:', error);
      await interaction.reply({
        content: '查询余额时发生错误，请稍后再试。',
        ephemeral: true
      });
    }
  }
};