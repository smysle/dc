const { SlashCommandBuilder } = require('@discordjs/builders');
const { User } = require('../models');
const config = require('../config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('绑定')
    .setDescription('绑定用户ID到Discord用户')
    .addStringOption(option => 
      option.setName('用户id')
        .setDescription('要绑定的用户ID')
        .setRequired(true))
    .addUserOption(option => 
      option.setName('目标用户')
        .setDescription('要绑定的Discord用户')
        .setRequired(true)),
    
  async execute(interaction) {
    try {
      // 检查权限
      const member = interaction.member;
      const hasPermission = member.roles.cache.some(role => 
        role.name === config.roles.admin || role.name === config.roles.superAdmin
      );
      
      if (!hasPermission) {
        return interaction.reply({
          content: '您没有权限执行此命令，只有管理员和超级管理员可以绑定用户。',
          ephemeral: true
        });
      }
      
      // 获取参数
      const userId = interaction.options.getString('用户id');
      const discordUser = interaction.options.getUser('目标用户');
      
      // 检查参数
      if (!userId || !discordUser) {
        return interaction.reply({
          content: '请提供正确的用户ID和Discord用户。',
          ephemeral: true
        });
      }
      
      // 检查用户ID是否已被绑定
      const existingUser = await User.findOne({ userId });
      if (existingUser && existingUser.boundId) {
        return interaction.reply({
          content: `用户ID ${userId} 已经绑定到其他Discord用户。`,
          ephemeral: true
        });
      }
      
      // 检查Discord用户是否已被绑定
      const existingDiscordUser = await User.findOne({ discordId: discordUser.id });
      if (existingDiscordUser && existingDiscordUser.boundId) {
        return interaction.reply({
          content: `Discord用户 ${discordUser.tag} 已经绑定到其他用户ID。`,
          ephemeral: true
        });
      }
      
      // 创建或更新用户
      let user = existingUser;
      if (!user) {
        user = new User({
          userId,
          username: discordUser.username,
          discordId: discordUser.id,
          boundId: userId,
          boundAt: new Date(),
          quota: config.quota.defaultAmount,
          usedQuota: 0,
          role: 'user'
        });
      } else {
        user.discordId = discordUser.id;
        user.username = discordUser.username;
        user.boundId = userId;
        user.boundAt = new Date();
      }
      
      // 保存用户
      await user.save();
      
      // 回复
      await interaction.reply({
        content: `成功绑定用户ID ${userId} 到Discord用户 ${discordUser.tag}。\n初始配额: $${config.quota.defaultAmount.toFixed(2)}`,
        ephemeral: true
      });
      
    } catch (error) {
      console.error('绑定用户时出错:', error);
      await interaction.reply({
        content: '绑定用户时发生错误，请稍后再试。',
        ephemeral: true
      });
    }
  }
};