const { SlashCommandBuilder } = require('@discordjs/builders');
const { User } = require('../models');
const config = require('../config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('设置管理员')
    .setDescription('将用户设置为管理员')
    .addUserOption(option => 
      option.setName('目标用户')
        .setDescription('要设置为管理员的Discord用户')
        .setRequired(true)),
    
  async execute(interaction) {
    try {
      // 检查权限
      const member = interaction.member;
      const isSuperAdmin = member.roles.cache.some(role => 
        role.name === config.roles.superAdmin
      );
      
      if (!isSuperAdmin) {
        return interaction.reply({
          content: '您没有权限执行此命令，只有超级管理员可以设置管理员。',
          ephemeral: true
        });
      }
      
      // 获取参数
      const discordUser = interaction.options.getUser('目标用户');
      
      // 查找用户
      let user = await User.findOne({ discordId: discordUser.id });
      
      if (!user) {
        // 如果用户不存在，创建一个新用户
        user = new User({
          username: discordUser.username,
          discordId: discordUser.id,
          quota: config.quota.defaultAmount,
          usedQuota: 0,
          role: 'user'
        });
      }
      
      // 检查用户是否已经是管理员
      if (user.role === 'admin') {
        return interaction.reply({
          content: `Discord用户 ${discordUser.tag} 已经是管理员。`,
          ephemeral: true
        });
      }
      
      // 设置为管理员
      user.role = 'admin';
      
      // 保存用户
      await user.save();
      
      // 尝试为用户添加Discord的管理员角色
      try {
        const guild = interaction.guild;
        const targetMember = await guild.members.fetch(discordUser.id);
        const adminRole = guild.roles.cache.find(role => role.name === config.roles.admin);
        
        if (adminRole) {
          await targetMember.roles.add(adminRole);
        }
      } catch (roleError) {
        console.warn('无法添加Discord管理员角色:', roleError);
      }
      
      // 回复
      await interaction.reply({
        content: `成功将Discord用户 ${discordUser.tag} 设置为管理员。`,
        ephemeral: true
      });
      
    } catch (error) {
      console.error('设置管理员时出错:', error);
      await interaction.reply({
        content: '设置管理员时发生错误，请稍后再试。',
        ephemeral: true
      });
    }
  }
};