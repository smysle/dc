const { SlashCommandBuilder } = require('@discordjs/builders');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ping')
    .setDescription('测试机器人是否在线'),
    
  async execute(interaction) {
    try {
      // 记录命令接收时间
      const received = Date.now();
      
      // 发送初始响应
      const response = await interaction.reply({
        content: '测试连接中...',
        ephemeral: true,
        fetchReply: true
      });
      
      // 计算API延迟
      const apiLatency = response.createdTimestamp - received;
      
      // 计算WebSocket心跳延迟
      const wsLatency = interaction.client.ws.ping;
      
      // 发送结果
      await interaction.editReply({
        content: `🏓 **Pong!**\n**API延迟:** ${apiLatency}ms\n**WebSocket延迟:** ${wsLatency}ms`,
        ephemeral: true
      });
      
    } catch (error) {
      console.error('Ping命令出错:', error);
      await interaction.reply({
        content: '测试连接时发生错误，请稍后再试。',
        ephemeral: true
      });
    }
  }
};