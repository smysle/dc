const mongoose = require('mongoose');
const { Schema } = mongoose;
const crypto = require('crypto');

// 管理员模型定义
const adminSchema = new Schema({
  // 用户名
  username: {
    type: String,
    required: true,
    unique: true
  },
  
  // 密码哈希
  passwordHash: {
    type: String,
    required: true
  },
  
  // 密码盐值
  salt: {
    type: String,
    required: true
  },
  
  // 是否为超级管理员
  isSuperAdmin: {
    type: Boolean,
    default: false
  },
  
  // 创建时间
  createdAt: {
    type: Date,
    default: Date.now
  },
  
  // 最后登录时间
  lastLogin: {
    type: Date,
    default: null
  }
});

// 设置密码方法
adminSchema.methods.setPassword = function(password) {
  this.salt = crypto.randomBytes(16).toString('hex');
  this.passwordHash = crypto
    .pbkdf2Sync(password, this.salt, 1000, 64, 'sha512')
    .toString('hex');
};

// 验证密码方法
adminSchema.methods.validatePassword = function(password) {
  const hash = crypto
    .pbkdf2Sync(password, this.salt, 1000, 64, 'sha512')
    .toString('hex');
  return this.passwordHash === hash;
};

// 创建默认管理员的静态方法
adminSchema.statics.createDefaultAdmin = async function(username, password) {
  try {
    // 检查是否已经存在管理员
    const existingAdmin = await this.findOne({ username });
    if (existingAdmin) {
      return existingAdmin;
    }
    
    // 创建新管理员
    const admin = new this({
      username,
      isSuperAdmin: true
    });
    
    admin.setPassword(password);
    await admin.save();
    return admin;
  } catch (error) {
    console.error('创建默认管理员失败:', error);
    throw error;
  }
};

// 创建并导出模型
const Admin = mongoose.model('Admin', adminSchema);
module.exports = Admin;