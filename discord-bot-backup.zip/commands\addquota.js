const { SlashCommandBuilder } = require('@discordjs/builders');
const { User } = require('../models');
const config = require('../config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('addquota')
    .setDescription('当配额低于100$时，为自己增加200$配额'),
    
  async execute(interaction) {
    try {
      const discordId = interaction.user.id;
      
      // 查找用户
      const user = await User.findOne({ discordId });
      
      if (!user) {
        return interaction.reply({
          content: '您尚未绑定ID，请联系管理员进行绑定。',
          ephemeral: true
        });
      }
      
      // 计算剩余配额
      const remainingQuota = user.quota - user.usedQuota;
      
      // 检查是否需要增加配额
      if (remainingQuota >= 100) {
        return interaction.reply({
          content: `您当前剩余配额为 $${remainingQuota.toFixed(2)}，高于 $100，无需增加配额。`,
          ephemeral: true
        });
      }
      
      // 记录原始配额
      const originalQuota = user.quota;
      
      // 增加配额
      user.quota += 200;
      
      // 添加配额历史记录
      user.quotaHistory.push({
        timestamp: new Date(),
        action: 'manual_refill',
        amount: 200,
        reason: '用户手动补充配额（余额低于$100）',
        adminId: 'user_self'
      });
      
      // 保存用户
      await user.save();
      
      // 回复用户
      await interaction.reply({
        content: `配额已成功增加!\n原余额: $${originalQuota.toFixed(2)}\n新余额: $${user.quota.toFixed(2)}\n增加金额: $200.00`,
        ephemeral: true
      });
      
    } catch (error) {
      console.error('增加配额时出错:', error);
      await interaction.reply({
        content: '增加配额时发生错误，请稍后再试。',
        ephemeral: true
      });
    }
  }
};