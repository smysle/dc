const mongoose = require('mongoose');
const config = require('../config');
const User = require('./User');
const Admin = require('./Admin');
const Setting = require('./Setting');

// 从数据库加载设置并更新配置
const loadSettings = async () => {
  try {
    // 初始化默认设置（如果尚未设置）
    await Setting.initDefaultSettings();
    
    // 加载所有设置，包括敏感信息
    const settings = await Setting.getAllSettings(true);
    
    // 将设置合并到配置对象中
    if (settings.bot_token) config.bot.token = settings.bot_token;
    if (settings.client_id) config.bot.clientId = settings.client_id;
    if (settings.guild_id) config.bot.guildId = settings.guild_id;
    if (settings.prefix) config.prefix = settings.prefix;
    
    if (settings.dollars_to_quota) config.quota.dollarsToQuota = settings.dollars_to_quota;
    if (settings.min_quota_dollars) config.quota.minQuotaDollars = settings.min_quota_dollars;
    if (settings.add_quota_dollars) config.quota.addQuotaDollars = settings.add_quota_dollars;
    if (settings.update_cooldown) config.quota.updateCooldown = settings.update_cooldown;
    
    if (settings.port) config.web.port = settings.port;
    if (settings.session_secret) config.web.sessionSecret = settings.session_secret;
    
    if (settings.super_admin_role) config.roles.superAdmin = settings.super_admin_role;
    if (settings.admin_role) config.roles.admin = settings.admin_role;
    
    console.log('系统设置已从数据库加载');
    
    // 检查必要的设置是否已配置
    const isConfigured = !!settings.bot_token;
    global.isSystemConfigured = isConfigured;
    
    return isConfigured;
  } catch (error) {
    console.error('加载设置时出错:', error);
    return false;
  }
};

// 连接到MongoDB数据库
const connectDB = async () => {
  try {
    const conn = await mongoose.connect(config.database.uri, {
      useNewUrlParser: true,
      useUnifiedTopology: true
    });
    
    console.log(`MongoDB已连接: ${conn.connection.host}`);
    
    // 加载系统设置
    const isConfigured = await loadSettings();
    
    // 创建默认管理员账户
    await Admin.createDefaultAdmin(
      config.web.defaultAdmin.username,
      config.web.defaultAdmin.password
    );
    console.log('已检查默认管理员账户');
    
    return { isConfigured };
  } catch (error) {
    console.error(`MongoDB连接错误: ${error.message}`);
    process.exit(1);
  }
};

module.exports = {
  connectDB,
  loadSettings,
  User,
  Admin,
  Setting
};