const { User } = require('../models');
const config = require('../config');

module.exports = {
  name: 'bind',
  description: '绑定用户ID (仅限管理员和超级管理员使用)',
  async execute(message, args) {
    // 检查执行命令的用户是否有管理员权限
    const member = message.member;
    const isSuperAdmin = member.roles.cache.some(role => role.name === config.roles.superAdmin);
    const isAdmin = isSuperAdmin || member.roles.cache.some(role => role.name === config.roles.admin);
    
    if (!isAdmin) {
      return message.reply('你没有权限执行此命令，只有管理员和超级管理员可以绑定用户ID。');
    }
    
    // 检查参数
    if (args.length < 2) {
      return message.reply(`使用方法不正确。正确格式：${config.prefix}bind <@用户> <ID>`);
    }
    
    // 获取目标用户
    const targetUser = message.mentions.users.first();
    if (!targetUser) {
      return message.reply('请正确提及(@)一个用户。');
    }
    
    // 获取要绑定的ID
    const idToBind = args[1];
    if (!idToBind) {
      return message.reply('请提供要绑定的ID。');
    }
    
    try {
      // 检查ID是否已被绑定
      const existingUser = await User.findOne({ boundId: idToBind });
      if (existingUser) {
        return message.reply(`ID "${idToBind}" 已经被绑定给用户 <@${existingUser.discordId}>。`);
      }
      
      // 查找或创建用户记录
      let user = await User.findOne({ discordId: targetUser.id });
      
      if (user) {
        // 如果用户已经绑定了ID
        if (user.boundId) {
          return message.reply(`用户 <@${targetUser.id}> 已经绑定了ID: ${user.boundId}`);
        }
        
        // 更新绑定ID
        user.boundId = idToBind;
        user.boundBy = message.author.id;
        user.boundAt = new Date();
      } else {
        // 创建新用户
        user = new User({
          discordId: targetUser.id,
          username: targetUser.username,
          boundId: idToBind,
          boundBy: message.author.id,
          boundAt: new Date()
        });
      }
      
      // 保存用户记录
      await user.save();
      
      message.reply(`成功将ID "${idToBind}" 绑定给用户 <@${targetUser.id}>`);
    } catch (error) {
      console.error('绑定ID时出错:', error);
      message.reply('绑定ID时发生错误，请稍后再试。');
    }
  }
};