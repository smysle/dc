/**
 * 配额辅助工具
 * 提供配额相关的辅助函数，确保在更新配额时保留所有用户属性
 */

const config = require('../config');

/**
 * 将配额转换为美元格式
 * @param {Number} quota - 配额数值
 * @returns {String} - 美元格式的配额
 */
function formatQuotaAsDollars(quota) {
  return `$${(quota / config.quota.dollarsToQuota).toFixed(2)}`;
}

/**
 * 创建配额更新操作对象，确保只更新必要字段
 * @param {Number} addQuota - 要增加的配额数量
 * @param {String} action - 操作类型
 * @param {String} reason - 操作原因
 * @param {String} adminId - 操作者ID
 * @returns {Object} - MongoDB更新操作对象
 */
function createQuotaUpdateOp(addQuota, action, reason, adminId) {
  // 创建历史记录条目
  const historyEntry = {
    timestamp: new Date(),
    action: action,
    amount: addQuota,
    reason: reason,
    adminId: adminId
  };
  
  // 返回更新操作对象
  return {
    $inc: { quota: addQuota },  // 增加配额
    $push: { quotaHistory: historyEntry },  // 添加历史记录
    $set: { lastQuotaUpdate: new Date() }  // 更新最后配额更新时间
  };
}

/**
 * 创建使用配额更新操作对象
 * @param {Number} usedAmount - 使用的配额数量
 * @param {String} reason - 操作原因
 * @param {String} adminId - 操作者ID
 * @returns {Object} - MongoDB更新操作对象
 */
function createUsedQuotaUpdateOp(usedAmount, reason, adminId) {
  // 创建历史记录条目
  const historyEntry = {
    timestamp: new Date(),
    action: 'use',
    amount: usedAmount,
    reason: reason || '使用配额',
    adminId: adminId || 'system'
  };
  
  // 返回更新操作对象
  return {
    $inc: { usedQuota: usedAmount },  // 增加已使用配额
    $push: { quotaHistory: historyEntry }  // 添加历史记录
  };
}

/**
 * 获取最小配额阈值（配额单位）
 * @returns {Number} - 最小配额阈值
 */
function getMinQuota() {
  return config.quota.minQuotaDollars * config.quota.dollarsToQuota; // 50,000,000
}

/**
 * 获取增加配额数量（配额单位）
 * @returns {Number} - 增加配额数量
 */
function getAddQuota() {
  return config.quota.addQuotaDollars * config.quota.dollarsToQuota; // 100,000,000
}

module.exports = {
  formatQuotaAsDollars,
  createQuotaUpdateOp,
  createUsedQuotaUpdateOp,
  getMinQuota,
  getAddQuota
};