const { SlashCommandBuilder } = require('@discordjs/builders');
const { MessageActionRow, MessageSelectMenu } = require('discord.js');
const { User } = require('../models');
const config = require('../config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('用户管理')
    .setDescription('用户管理菜单，仅管理员可用'),
    
  async execute(interaction) {
    try {
      // 检查权限
      const member = interaction.member;
      const hasPermission = member.roles.cache.some(role => 
        role.name === config.roles.admin || role.name === config.roles.superAdmin
      );
      
      if (!hasPermission) {
        return interaction.reply({
          content: '您没有权限执行此命令，只有管理员和超级管理员可以使用用户管理功能。',
          ephemeral: true
        });
      }
      
      // 获取所有已绑定用户
      const users = await User.find({ boundId: { $ne: null } })
        .sort({ username: 1 })
        .limit(25); // 限制25个用户以避免超出Discord限制
      
      if (!users || users.length === 0) {
        return interaction.reply({
          content: '当前没有已绑定的用户。',
          ephemeral: true
        });
      }
      
      // 创建用户选择菜单
      const row = new MessageActionRow()
        .addComponents(
          new MessageSelectMenu()
            .setCustomId('select_user_to_view')
            .setPlaceholder('选择要查看的用户')
            .addOptions(
              users.map(user => ({
                label: user.username || '未知用户',
                description: `ID: ${user.userId || '未绑定'} | 余额: $${(user.quota - user.usedQuota).toFixed(2)}`,
                value: user.discordId,
                emoji: user.role === 'admin' ? '👑' : '👤'
              }))
            )
        );
      
      // 发送带选择菜单的消息
      await interaction.reply({
        content: '请选择要查看或管理的用户：',
        components: [row],
        ephemeral: true
      });
      
    } catch (error) {
      console.error('生成用户管理菜单时出错:', error);
      await interaction.reply({
        content: '生成用户管理菜单时发生错误，请稍后再试。',
        ephemeral: true
      });
    }
  }
};