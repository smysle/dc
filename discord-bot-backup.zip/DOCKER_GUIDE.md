# Docker部署指南

本文档提供了使用Docker部署Discord配额管理系统的详细指南。

## 环境要求

- Docker Engine 19.03+
- Docker Compose 1.27+
- 至少2GB RAM
- 至少10GB磁盘空间

## 快速部署

### 1. 准备.env文件

首先，创建数据目录并准备环境变量文件：

```bash
# 创建数据目录
mkdir -p data

# 创建环境变量文件
cp .env.example data/.env

# 编辑.env文件，填入您的Discord Bot Token和其他配置
nano data/.env
```

在.env文件中，至少需要设置以下内容：

```
# Discord Bot 设置
DISCORD_TOKEN=您的机器人令牌
DISCORD_CLIENT_ID=您的应用ID

# Web管理界面设置
SESSION_SECRET=随机生成的会话密钥
ADMIN_USERNAME=管理员用户名
ADMIN_PASSWORD=管理员密码

# 角色配置
SUPER_ADMIN_ROLE=超级管理员
ADMIN_ROLE=管理员
```

### 2. 启动服务

使用Docker Compose启动所有服务：

```bash
docker-compose up -d
```

这将启动以下服务：
- Discord Bot和Web服务 (端口3000)
- MongoDB数据库 (端口27017)
- Redis缓存服务 (端口6379)

### 3. 查看日志

查看应用日志以确保一切正常运行：

```bash
docker-compose logs -f app
```

## 新功能支持说明

本Docker部署已配置支持以下新功能：

### 1. 中文斜杠命令

系统支持全中文斜杠命令，如`/查询余额`、`/增加额度`等。这些命令在部署后即可使用，无需额外配置。

### 2. 选择菜单功能

Docker部署已包含选择菜单功能支持，包括：
- 用户操作菜单 (`/菜单`)
- 管理员用户管理菜单 (`/用户管理`)

### 3. 交互式按钮

系统配置支持交互式按钮功能，用户可以通过点击按钮增加配额等。

### 4. 私聊支持

Docker部署已配置支持私聊功能，用户可以直接私聊机器人使用所有命令。

### 5. 安全配额更新

Docker部署包含最新的安全配额更新功能，解决了以下问题：

- 修复了更新配额时可能导致用户信息（用户名、分组、访问令牌等）丢失的问题
- 使用部分更新而非保存整个文档，确保只更新必要字段
- 添加了提示信息，告知用户系统会保留所有原始信息
- 添加了详细的文档和最佳实践指南（位于`docs/SAFE_QUOTA_UPDATE.md`）

查看`docs/SAFE_QUOTA_UPDATE.md`了解更多关于安全更新配额的信息。

## 服务维护

### 重启服务

```bash
docker-compose restart app
```

### 更新系统

```bash
# 拉取最新代码
git pull

# 重建并重启容器
docker-compose up -d --build
```

### 备份数据

```bash
# 备份MongoDB数据
tar -czvf backup-$(date +%Y%m%d).tar.gz data/db

# 备份Redis数据
tar -czvf redis-backup-$(date +%Y%m%d).tar.gz data/redis
```

## 故障排除

### 机器人无法连接

检查.env文件中的Discord令牌是否正确：

```bash
docker-compose logs app | grep "Discord Bot登录失败"
```

### 数据库连接问题

检查MongoDB连接：

```bash
docker-compose logs mongodb
```

### 缓存服务问题

检查Redis连接：

```bash
docker-compose logs redis
```

如果Redis连接失败，系统会自动降级为使用内存缓存，但部分功能可能会受限。

## 注意事项

1. **数据持久化**：所有数据都存储在`./data`目录中，确保此目录有适当的备份。
2. **环境变量**：重要的配置都通过环境变量提供，切勿在代码中硬编码敏感信息。
3. **资源限制**：默认配置适用于中小规模部署，如果用户数量大，可能需要调整资源限制。