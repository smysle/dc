const express = require('express');
const session = require('express-session');
const MongoStore = require('connect-mongo');
const path = require('path');
const morgan = require('morgan');
const cors = require('cors');
const config = require('../config');
const { connectDB } = require('../models');
const { deviceDetectionMiddleware } = require('../utils/device');
const { performanceMiddlewares } = require('../utils/compression');
const { initCache, cacheMiddleware } = require('../utils/cache');

// 创建Express应用
const app = express();

// 设置视图引擎
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// 中间件
app.use(morgan('dev')); // 日志
app.use(cors()); // 跨域支持
app.use(express.json()); // JSON解析
app.use(express.urlencoded({ extended: true })); // 表单解析

// 性能优化中间件
const performance = performanceMiddlewares();
performance.forEach(middleware => app.use(middleware));

app.use(express.static(path.join(__dirname, 'public'), {
  maxAge: '1d' // 静态资源缓存1天
})); // 静态文件

app.use(deviceDetectionMiddleware); // 设备检测中间件

// 会话配置
app.use(
  session({
    secret: config.web.sessionSecret,
    resave: false,
    saveUninitialized: false,
    store: MongoStore.create({
      mongoUrl: config.database.uri,
      collectionName: 'sessions'
    }),
    cookie: {
      maxAge: 1000 * 60 * 60 * 24 // 1天
    }
  })
);

// API缓存中间件
app.use('/api', cacheMiddleware({
  ttl: 60, // API结果缓存60秒
  methods: ['GET'],
  shouldCache: (req) => {
    // 不缓存用户特定或敏感API
    return !(
      req.path.includes('/users/') ||
      req.path.includes('/admin/') ||
      req.path.includes('/auth/')
    );
  }
}));

// 路由
app.use('/', require('./routes/index'));
app.use('/api', require('./routes/api'));
app.use('/admin', require('./routes/admin'));
app.use('/settings', require('./routes/settings'));
app.use('/monitor', require('./routes/monitor'));
app.use('/quota', require('./routes/quota'));

// 错误处理
app.use((req, res, next) => {
  res.status(404).render('error', {
    title: '页面未找到',
    message: '您访问的页面不存在',
    error: { status: 404 }
  });
});

app.use((err, req, res, next) => {
  res.status(err.status || 500).render('error', {
    title: '错误',
    message: err.message,
    error: process.env.NODE_ENV === 'development' ? err : {}
  });
});

// 启动服务器
const startServer = async () => {
  try {
    // 连接数据库
    await connectDB();
    
    // 初始化缓存 - 根据环境自动选择缓存方式
    const { redisAvailable } = require('../utils/cache');
    await initCache();
    console.log(`缓存系统已初始化，使用${redisAvailable ? 'Redis' : '内存'}缓存`);
    
    // 启动服务器
    const port = config.web.port || 3000;
    app.listen(port, () => {
      console.log(`Web服务器已启动，端口: ${port}`);
    });
  } catch (error) {
    console.error('启动Web服务器时出错:', error);
    process.exit(1);
  }
};

// 如果直接运行此文件，则启动服务器
if (require.main === module) {
  startServer();
}

module.exports = { app, startServer };