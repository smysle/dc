/**
 * 资源压缩工具
 * 用于优化Web应用的资源加载速度和网络带宽使用
 */

const compression = require('compression');

/**
 * 创建gzip压缩中间件
 * @param {Object} options - 压缩选项
 * @returns {Function} - Express中间件
 */
function createCompressionMiddleware(options = {}) {
  const defaultOptions = {
    // 设置过滤条件，只有超过这个大小的响应才会被压缩
    threshold: 1024, // 1KB
    
    // 设置压缩级别 (0-9)，9为最高压缩率
    level: 6,
    
    // 设置内存级别 (1-9)，影响压缩速度和内存使用
    memLevel: 8,
    
    // 根据请求的Content-Type决定是否压缩
    filter: (req, res) => {
      const contentType = res.getHeader('Content-Type') || '';
      
      // 只压缩这些类型
      return /text|javascript|json|css|xml|font|application\/.*\+json/.test(contentType);
    }
  };
  
  // 合并选项
  const finalOptions = { ...defaultOptions, ...options };
  
  return compression(finalOptions);
}

/**
 * 缓存控制中间件
 * 设置不同资源类型的缓存策略
 * @returns {Function} - Express中间件
 */
function cacheControlMiddleware() {
  return (req, res, next) => {
    // 静态资源URL模式
    const staticPattern = /\.(css|js|jpg|jpeg|png|gif|ico|svg|woff|woff2|ttf|eot)$/i;
    
    // 如果是静态资源，设置缓存策略
    if (staticPattern.test(req.url)) {
      const match = req.url.match(staticPattern);
      const ext = match[1].toLowerCase();
      
      // 根据不同资源类型设置不同的缓存时间
      if (['css', 'js'].includes(ext)) {
        // CSS和JavaScript文件缓存1天
        res.setHeader('Cache-Control', 'public, max-age=86400');
      } else if (['jpg', 'jpeg', 'png', 'gif', 'ico', 'svg'].includes(ext)) {
        // 图片缓存7天
        res.setHeader('Cache-Control', 'public, max-age=604800');
      } else if (['woff', 'woff2', 'ttf', 'eot'].includes(ext)) {
        // 字体文件缓存30天
        res.setHeader('Cache-Control', 'public, max-age=2592000');
      }
    } else {
      // API或动态页面设置为不缓存
      res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
      res.setHeader('Pragma', 'no-cache');
      res.setHeader('Expires', '0');
    }
    
    next();
  };
}

/**
 * 性能优化中间件集合
 * 包含压缩和缓存控制
 * @param {Object} options - 选项
 * @returns {Array} - 中间件数组
 */
function performanceMiddlewares(options = {}) {
  return [
    createCompressionMiddleware(options.compression),
    cacheControlMiddleware()
  ];
}

module.exports = {
  createCompressionMiddleware,
  cacheControlMiddleware,
  performanceMiddlewares
};