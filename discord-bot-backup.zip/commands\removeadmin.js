const { User } = require('../models');
const config = require('../config');

module.exports = {
  name: 'removeadmin',
  description: '移除用户的管理员权限 (仅限超级管理员使用)',
  async execute(message, args) {
    // 检查执行命令的用户是否有超级管理员权限
    const member = message.member;
    const isSuperAdmin = member.roles.cache.some(role => role.name === config.roles.superAdmin);
    
    if (!isSuperAdmin) {
      return message.reply('你没有权限执行此命令，只有超级管理员可以移除管理员权限。');
    }
    
    // 检查参数
    if (args.length < 1) {
      return message.reply(`使用方法不正确。正确格式：${config.prefix}removeadmin <@用户>`);
    }
    
    // 获取目标用户
    const targetUser = message.mentions.users.first();
    if (!targetUser) {
      return message.reply('请正确提及(@)一个用户。');
    }
    
    // 获取目标成员对象
    const targetMember = message.guild.members.cache.get(targetUser.id);
    if (!targetMember) {
      return message.reply('无法获取目标用户的成员信息。');
    }
    
    try {
      // 检查目标用户是否有管理员角色
      const adminRole = message.guild.roles.cache.find(role => role.name === config.roles.admin);
      
      if (!adminRole) {
        return message.reply(`在服务器中找不到名为 "${config.roles.admin}" 的角色。`);
      }
      
      const hasAdminRole = targetMember.roles.cache.has(adminRole.id);
      
      if (!hasAdminRole) {
        return message.reply(`用户 <@${targetUser.id}> 不是管理员。`);
      }
      
      // 移除Discord服务器中的管理员角色
      await targetMember.roles.remove(adminRole);
      
      // 更新数据库中的用户角色
      let user = await User.findOne({ discordId: targetUser.id });
      
      if (user) {
        user.role = 'user';
        await user.save();
      }
      
      message.reply(`成功移除用户 <@${targetUser.id}> 的管理员权限。`);
    } catch (error) {
      console.error('移除管理员权限时出错:', error);
      message.reply('移除管理员权限时发生错误，请稍后再试。');
    }
  }
};