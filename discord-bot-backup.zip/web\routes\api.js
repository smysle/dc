const express = require('express');
const router = express.Router();
const { User } = require('../../models');
const config = require('../../config');

// 中间件：检查API认证
const checkApiAuth = (req, res, next) => {
  if (!req.session.user) {
    return res.status(401).json({ success: false, message: '未授权' });
  }
  next();
};

// 获取所有用户
router.get('/users', checkApiAuth, async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 20;
    
    // 过滤条件
    const filter = {};
    if (req.query.bound === 'true') {
      filter.boundId = { $ne: null };
    } else if (req.query.bound === 'false') {
      filter.boundId = null;
    }
    
    if (req.query.role) {
      filter.role = req.query.role;
    }
    
    if (req.query.search) {
      const search = req.query.search;
      filter.$or = [
        { username: { $regex: search, $options: 'i' } },
        { boundId: { $regex: search, $options: 'i' } },
        { discordId: { $regex: search, $options: 'i' } }
      ];
    }
    
    // 排序设置
    const sortField = req.query.sortBy || 'createdAt';
    const sortOrder = req.query.sortOrder === 'asc' ? 1 : -1;
    const sort = { [sortField]: sortOrder };
    
    // 使用分页静态方法获取数据
    const result = await User.findPaginated(filter, {
      page,
      limit,
      sort
    });
    
    // 返回结果
    res.json({
      success: true,
      data: {
        users: result.data,
        pagination: result.pagination
      }
    });
  } catch (error) {
    console.error('获取用户数据错误:', error);
    res.status(500).json({ success: false, message: '获取用户数据时发生错误', error: error.message });
  }
});

// 获取单个用户
router.get('/users/:id', checkApiAuth, async (req, res) => {
  try {
    const user = await User.findOne({ 
      $or: [
        { _id: req.params.id },
        { discordId: req.params.id },
        { boundId: req.params.id }
      ]
    });
    
    if (!user) {
      return res.status(404).json({ success: false, message: '用户不存在' });
    }
    
    res.json({ success: true, data: user });
  } catch (error) {
    console.error('获取用户详情错误:', error);
    res.status(500).json({ success: false, message: '获取用户详情时发生错误', error: error.message });
  }
});

// 更新用户配额
router.post('/users/:id/update-quota', checkApiAuth, async (req, res) => {
  try {
    const { amount, reason } = req.body;
    
    if (!amount) {
      return res.status(400).json({ success: false, message: '请提供配额金额' });
    }
    
    const user = await User.findOne({ 
      $or: [
        { _id: req.params.id },
        { discordId: req.params.id },
        { boundId: req.params.id }
      ]
    });
    
    if (!user) {
      return res.status(404).json({ success: false, message: '用户不存在' });
    }
    
    // 计算实际配额变化
    const quotaChange = amount * config.quota.dollarsToQuota;
    const oldQuota = user.quota || 0;
    const newQuota = oldQuota + quotaChange;
    
    // 更新用户配额
    user.quota = newQuota;
    user.lastQuotaUpdate = new Date();
    
    // 添加到配额历史记录
    user.quotaHistory.push({
      amount: quotaChange,
      timestamp: new Date(),
      reason: reason || `由管理员 ${req.session.user.username} 手动更新`
    });
    
    await user.save();
    
    res.json({
      success: true,
      message: '配额更新成功',
      data: {
        user,
        update: {
          oldQuota,
          newQuota,
          change: quotaChange
        }
      }
    });
  } catch (error) {
    console.error('更新配额错误:', error);
    res.status(500).json({ success: false, message: '更新配额时发生错误', error: error.message });
  }
});

// 获取配额排行榜
router.get('/quota-leaderboard', checkApiAuth, async (req, res) => {
  try {
    const days = parseInt(req.query.days) || 1;
    const limit = parseInt(req.query.limit) || 10;
    
    // 计算时间范围
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - days);
    
    // 聚合获取排行榜数据
    const leaderboard = await User.aggregate([
      // 解开配额历史数组
      { $unwind: '$quotaHistory' },
      // 筛选时间范围内的记录
      { $match: { 'quotaHistory.timestamp': { $gte: startDate } } },
      // 按用户分组并计算总配额变化
      { $group: {
          _id: '$_id',
          discordId: { $first: '$discordId' },
          username: { $first: '$username' },
          boundId: { $first: '$boundId' },
          totalAdded: { $sum: '$quotaHistory.amount' },
          updateCount: { $sum: 1 }
        }
      },
      // 按总配额变化排序
      { $sort: { totalAdded: -1 } },
      // 限制结果数量
      { $limit: limit }
    ]);
    
    res.json({
      success: true,
      data: {
        days,
        leaderboard
      }
    });
  } catch (error) {
    console.error('获取排行榜错误:', error);
    res.status(500).json({ success: false, message: '获取排行榜时发生错误', error: error.message });
  }
});

// 获取配额统计
router.get('/quota-stats', checkApiAuth, async (req, res) => {
  try {
    // 计算总配额和已用配额
    const quotaStats = await User.aggregate([
      { $group: {
          _id: null,
          totalQuota: { $sum: '$quota' },
          totalUsedQuota: { $sum: '$usedQuota' },
          userCount: { $sum: 1 }
        }
      }
    ]);
    
    // 计算今日增加的配额
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    const todayStats = await User.aggregate([
      { $unwind: '$quotaHistory' },
      { $match: { 'quotaHistory.timestamp': { $gte: today } } },
      { $group: {
          _id: null,
          totalAdded: { $sum: '$quotaHistory.amount' },
          updateCount: { $sum: 1 }
        }
      }
    ]);
    
    res.json({
      success: true,
      data: {
        quotaStats: quotaStats[0] || { totalQuota: 0, totalUsedQuota: 0, userCount: 0 },
        todayStats: todayStats[0] || { totalAdded: 0, updateCount: 0 }
      }
    });
  } catch (error) {
    console.error('获取配额统计错误:', error);
    res.status(500).json({ success: false, message: '获取配额统计时发生错误', error: error.message });
  }
});

module.exports = router;