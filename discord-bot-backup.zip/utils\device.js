/**
 * 设备检测工具
 * 用于检测用户设备类型和优化用户体验
 */

/**
 * 检测是否为移动设备
 * @param {Object} req - Express请求对象
 * @returns {boolean} 是否为移动设备
 */
function isMobileDevice(req) {
  const userAgent = req.headers['user-agent'] || '';
  
  // 移动设备特征
  const mobileRegex = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini|Mobile|mobile|CriOS/i;
  
  return mobileRegex.test(userAgent);
}

/**
 * 移动设备响应式中间件
 * 自动检测设备类型并添加到locals
 */
function deviceDetectionMiddleware(req, res, next) {
  // 检测设备类型
  const isMobile = isMobileDevice(req);
  
  // 将设备信息添加到locals，供视图使用
  res.locals.deviceInfo = {
    isMobile,
    isDesktop: !isMobile,
    userAgent: req.headers['user-agent']
  };
  
  next();
}

/**
 * 获取视图尺寸类别
 * 根据Bootstrap的响应式断点
 * @param {number} width - 视口宽度
 * @returns {string} 尺寸类别
 */
function getViewportSize(width) {
  if (width < 576) return 'xs';
  if (width < 768) return 'sm';
  if (width < 992) return 'md';
  if (width < 1200) return 'lg';
  return 'xl';
}

module.exports = {
  isMobileDevice,
  deviceDetectionMiddleware,
  getViewportSize
};