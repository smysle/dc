/**
 * 系统监控工具
 * 用于收集和展示系统资源使用、请求量和错误率等指标
 */

const os = require('os');
const { EventEmitter } = require('events');

// 监控事件发射器
const monitorEmitter = new EventEmitter();

// 存储监控数据
const monitorData = {
  // 系统资源
  system: {
    startTime: Date.now(),
    cpuUsage: [],
    memoryUsage: [],
    heapUsage: []
  },
  
  // API请求
  requests: {
    total: 0,
    success: 0,
    failed: 0,
    routes: {}, // 按路由统计
    responseTime: [] // 响应时间统计
  },
  
  // 数据库操作
  database: {
    queries: 0,
    inserts: 0,
    updates: 0,
    deletes: 0,
    errors: 0,
    avgQueryTime: 0
  },
  
  // 错误统计
  errors: {
    total: 0,
    types: {}, // 按错误类型统计
    recent: [] // 最近的错误
  },
  
  // Discord Bot
  bot: {
    commands: 0,
    events: 0,
    errors: 0
  }
};

// 每分钟收集的数据点数量限制
const DATA_POINTS_LIMIT = 60 * 24; // 24小时的分钟数

/**
 * 收集系统资源使用情况
 */
function collectSystemMetrics() {
  // CPU使用率
  const cpus = os.cpus();
  let totalIdle = 0;
  let totalTick = 0;
  
  cpus.forEach(cpu => {
    for (const type in cpu.times) {
      totalTick += cpu.times[type];
    }
    totalIdle += cpu.times.idle;
  });
  
  const idlePercent = totalIdle / totalTick;
  const cpuUsage = 100 - (idlePercent * 100);
  
  // 内存使用率
  const totalMem = os.totalmem();
  const freeMem = os.freemem();
  const memoryUsage = ((totalMem - freeMem) / totalMem) * 100;
  
  // Node.js堆内存使用
  const heapUsage = process.memoryUsage();
  
  // 更新监控数据
  monitorData.system.cpuUsage.push({ time: Date.now(), value: cpuUsage });
  monitorData.system.memoryUsage.push({ time: Date.now(), value: memoryUsage });
  monitorData.system.heapUsage.push({ 
    time: Date.now(), 
    rss: heapUsage.rss, 
    heapTotal: heapUsage.heapTotal, 
    heapUsed: heapUsage.heapUsed
  });
  
  // 限制数据点数量
  if (monitorData.system.cpuUsage.length > DATA_POINTS_LIMIT) {
    monitorData.system.cpuUsage.shift();
  }
  if (monitorData.system.memoryUsage.length > DATA_POINTS_LIMIT) {
    monitorData.system.memoryUsage.shift();
  }
  if (monitorData.system.heapUsage.length > DATA_POINTS_LIMIT) {
    monitorData.system.heapUsage.shift();
  }
  
  // 发出事件
  monitorEmitter.emit('system-metrics-updated', {
    cpuUsage,
    memoryUsage,
    heapUsage
  });
}

/**
 * 记录API请求
 * @param {Object} req - Express请求对象
 * @param {Object} res - Express响应对象
 * @param {Function} next - Next中间件函数
 */
function requestMonitorMiddleware(req, res, next) {
  // 请求开始时间
  const startTime = Date.now();
  
  // 路由路径
  const route = req.originalUrl || req.url;
  
  // 增加总请求计数
  monitorData.requests.total++;
  
  // 初始化路由统计
  if (!monitorData.requests.routes[route]) {
    monitorData.requests.routes[route] = {
      total: 0,
      success: 0,
      failed: 0
    };
  }
  monitorData.requests.routes[route].total++;
  
  // 修改响应结束事件，记录响应结果
  const originalEnd = res.end;
  res.end = function() {
    // 响应结束时间
    const responseTime = Date.now() - startTime;
    
    // 记录响应时间
    monitorData.requests.responseTime.push({ time: Date.now(), value: responseTime, route });
    if (monitorData.requests.responseTime.length > DATA_POINTS_LIMIT * 10) {
      monitorData.requests.responseTime.shift();
    }
    
    // 根据状态码判断请求是否成功
    if (res.statusCode >= 200 && res.statusCode < 400) {
      monitorData.requests.success++;
      monitorData.requests.routes[route].success++;
    } else {
      monitorData.requests.failed++;
      monitorData.requests.routes[route].failed++;
      
      // 如果是错误响应，记录错误
      if (res.statusCode >= 400) {
        recordError('HTTP', `${res.statusCode} on ${route}`);
      }
    }
    
    // 发出事件
    monitorEmitter.emit('request-completed', {
      route,
      method: req.method,
      statusCode: res.statusCode,
      responseTime,
      ip: req.ip
    });
    
    // 调用原始的end方法
    originalEnd.apply(res, arguments);
  };
  
  next();
}

/**
 * 记录数据库操作
 * @param {string} operation - 操作类型 (query, insert, update, delete)
 * @param {number} time - 操作耗时(毫秒)
 * @param {boolean} isError - 是否出错
 */
function recordDatabaseOperation(operation, time, isError = false) {
  // 更新计数
  monitorData.database[operation + 's']++;
  
  if (isError) {
    monitorData.database.errors++;
  }
  
  // 更新平均查询时间
  const oldAvg = monitorData.database.avgQueryTime;
  const totalOps = monitorData.database.queries + 
                   monitorData.database.inserts + 
                   monitorData.database.updates + 
                   monitorData.database.deletes;
  
  monitorData.database.avgQueryTime = 
    (oldAvg * (totalOps - 1) + time) / totalOps;
  
  // 发出事件
  monitorEmitter.emit('database-operation', {
    operation,
    time,
    isError
  });
}

/**
 * 记录错误
 * @param {string} type - 错误类型
 * @param {string} message - 错误消息
 * @param {Object} [details] - 详细信息
 */
function recordError(type, message, details = {}) {
  // 更新错误计数
  monitorData.errors.total++;
  
  // 更新错误类型统计
  if (!monitorData.errors.types[type]) {
    monitorData.errors.types[type] = 0;
  }
  monitorData.errors.types[type]++;
  
  // 添加到最近错误列表
  monitorData.errors.recent.unshift({
    time: Date.now(),
    type,
    message,
    details
  });
  
  // 限制最近错误列表长度
  if (monitorData.errors.recent.length > 100) {
    monitorData.errors.recent.pop();
  }
  
  // 发出事件
  monitorEmitter.emit('error-recorded', {
    type,
    message,
    details
  });
}

/**
 * 记录Bot命令执行
 * @param {string} command - 命令名称
 * @param {boolean} isSuccess - 是否执行成功
 */
function recordBotCommand(command, isSuccess = true) {
  monitorData.bot.commands++;
  
  if (!isSuccess) {
    monitorData.bot.errors++;
  }
  
  // 发出事件
  monitorEmitter.emit('bot-command', {
    command,
    isSuccess,
    time: Date.now()
  });
}

/**
 * 获取监控数据快照
 * @param {string} [section] - 指定要获取的数据部分
 * @returns {Object} 监控数据
 */
function getMonitorData(section) {
  if (section && monitorData[section]) {
    return { ...monitorData[section] };
  }
  
  return { ...monitorData };
}

/**
 * 获取系统状态摘要
 * @returns {Object} 系统状态摘要
 */
function getSystemSummary() {
  // 计算CPU和内存使用的平均值
  let avgCpu = 0;
  let avgMem = 0;
  
  if (monitorData.system.cpuUsage.length > 0) {
    avgCpu = monitorData.system.cpuUsage
      .slice(-10)
      .reduce((sum, item) => sum + item.value, 0) / 
      Math.min(monitorData.system.cpuUsage.length, 10);
  }
  
  if (monitorData.system.memoryUsage.length > 0) {
    avgMem = monitorData.system.memoryUsage
      .slice(-10)
      .reduce((sum, item) => sum + item.value, 0) / 
      Math.min(monitorData.system.memoryUsage.length, 10);
  }
  
  // 计算请求成功率
  const successRate = monitorData.requests.total > 0 
    ? (monitorData.requests.success / monitorData.requests.total) * 100 
    : 100;
  
  // 计算平均响应时间
  let avgResponseTime = 0;
  if (monitorData.requests.responseTime.length > 0) {
    avgResponseTime = monitorData.requests.responseTime
      .slice(-100)
      .reduce((sum, item) => sum + item.value, 0) / 
      Math.min(monitorData.requests.responseTime.length, 100);
  }
  
  // 系统运行时间(毫秒)
  const uptime = Date.now() - monitorData.system.startTime;
  
  return {
    uptime,
    avgCpuUsage: avgCpu,
    avgMemoryUsage: avgMem,
    heapUsed: monitorData.system.heapUsage.length > 0 
      ? monitorData.system.heapUsage[monitorData.system.heapUsage.length - 1].heapUsed 
      : 0,
    requestsTotal: monitorData.requests.total,
    requestsSuccess: monitorData.requests.success,
    requestsFailed: monitorData.requests.failed,
    successRate,
    avgResponseTime,
    errorsTotal: monitorData.errors.total,
    databaseOperations: monitorData.database.queries + 
                        monitorData.database.inserts + 
                        monitorData.database.updates + 
                        monitorData.database.deletes,
    databaseErrors: monitorData.database.errors,
    botCommands: monitorData.bot.commands,
    botErrors: monitorData.bot.errors
  };
}

/**
 * 启动监控系统
 */
function startMonitoring() {
  // 每分钟收集系统指标
  setInterval(collectSystemMetrics, 60000);
  
  // 初始收集一次
  collectSystemMetrics();
  
  console.log('系统监控已启动');
}

module.exports = {
  startMonitoring,
  requestMonitorMiddleware,
  recordDatabaseOperation,
  recordError,
  recordBotCommand,
  getMonitorData,
  getSystemSummary,
  monitorEmitter
};