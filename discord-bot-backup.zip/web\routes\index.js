const express = require('express');
const router = express.Router();
const { User } = require('../../models');
const config = require('../../config');
const moment = require('moment');

// 中间件：检查是否已登录
const isAuthenticated = (req, res, next) => {
  if (req.session.user) {
    return next();
  }
  res.redirect('/login');
};

// 主页 - 重定向到登录页或仪表板
router.get('/', (req, res) => {
  if (req.session.user) {
    // 检查系统是否已配置
    if (global.systemStatus && global.systemStatus.needsConfiguration && req.session.user.isSuperAdmin) {
      // 如果未配置且当前用户是超级管理员，重定向到设置向导
      res.redirect('/settings/wizard');
    } else {
      // 否则重定向到仪表板
      res.redirect('/dashboard');
    }
  } else {
    res.redirect('/login');
  }
});

// 登录页面
router.get('/login', (req, res) => {
  if (req.session.user) {
    return res.redirect('/dashboard');
  }
  res.render('login', {
    title: '登录',
    error: req.query.error
  });
});

// 处理登录请求
router.post('/login', async (req, res) => {
  const { username, password } = req.body;
  
  if (!username || !password) {
    return res.redirect('/login?error=请输入用户名和密码');
  }
  
  try {
    const { Admin } = require('../../models');
    const admin = await Admin.findOne({ username });
    
    if (!admin || !admin.validatePassword(password)) {
      return res.redirect('/login?error=用户名或密码不正确');
    }
    
    // 设置会话
    req.session.user = {
      id: admin._id,
      username: admin.username,
      isSuperAdmin: admin.isSuperAdmin
    };
    
    // 更新最后登录时间
    admin.lastLogin = new Date();
    await admin.save();
    
    res.redirect('/dashboard');
  } catch (error) {
    console.error('登录错误:', error);
    res.redirect('/login?error=登录过程中发生错误');
  }
});

// 注销
router.get('/logout', (req, res) => {
  req.session.destroy();
  res.redirect('/login');
});

// 仪表板 - 需要登录
router.get('/dashboard', isAuthenticated, async (req, res) => {
  // 检查系统是否已配置
  if (global.systemStatus && global.systemStatus.needsConfiguration && req.session.user.isSuperAdmin) {
    // 如果未配置且当前用户是超级管理员，重定向到设置向导
    return res.redirect('/settings/wizard');
  }
  
  // 导入可视化工具
  const {
    generateQuotaChartConfig,
    generateUserStatsChartConfig,
    generateQuotaDistributionChartConfig
  } = require('../../utils/visualize');
  try {
    // 获取用户统计信息
    const totalUsers = await User.countDocuments();
    const boundUsers = await User.countDocuments({ boundId: { $ne: null } });
    
    // 获取最近绑定的用户
    const recentBound = await User.find({ boundId: { $ne: null } })
      .sort({ boundAt: -1 })
      .limit(10);
    
    // 计算配额统计
    const quotaStats = await User.aggregate([
      { $match: { boundId: { $ne: null } } },
      { $group: {
          _id: null,
          totalQuota: { $sum: '$quota' },
          totalUsedQuota: { $sum: '$usedQuota' },
          avgQuota: { $avg: '$quota' }
        }
      }
    ]);
    
    // 获取最近24小时内增加配额的用户
    const oneDayAgo = new Date();
    oneDayAgo.setDate(oneDayAgo.getDate() - 1);
    
    const recentQuotaUpdates = await User.find({
      'quotaHistory.timestamp': { $gte: oneDayAgo }
    }).sort({ 'quotaHistory.timestamp': -1 }).limit(10);
    
    // 获取过去24小时的配额历史记录作为图表数据
    const quotaHistory = [];
    recentQuotaUpdates.forEach(user => {
      if (user.quotaHistory && user.quotaHistory.length > 0) {
        user.quotaHistory.forEach(history => {
          if (history.timestamp >= oneDayAgo) {
            quotaHistory.push(history);
          }
        });
      }
    });

    // 生成图表配置
    const quotaChartConfig = generateQuotaChartConfig({
      hourly: quotaHistory
    }, 'daily');
    
    const userStatsChartConfig = generateUserStatsChartConfig({
      total: totalUsers,
      bound: boundUsers,
      unbound: totalUsers - boundUsers,
      active: recentQuotaUpdates.length,
      inactive: totalUsers - recentQuotaUpdates.length
    });
    
    const quotaDistChartConfig = generateQuotaDistributionChartConfig(
      await User.find({}, 'quota').lean()
    );
    
    // 转换为JSON字符串
    const chartConfigs = {
      quotaChart: JSON.stringify(quotaChartConfig),
      userStatsChart: JSON.stringify(userStatsChartConfig),
      quotaDistChart: JSON.stringify(quotaDistChartConfig)
    };
    
    res.render('dashboard', {
      title: '仪表板',
      user: req.session.user,
      stats: {
        totalUsers,
        boundUsers,
        unboundUsers: totalUsers - boundUsers,
        quotaStats: quotaStats[0] || { totalQuota: 0, totalUsedQuota: 0, avgQuota: 0 }
      },
      recentBound,
      recentQuotaUpdates,
      moment,
      config,
      chartConfigs
    });
  } catch (error) {
    console.error('仪表板错误:', error);
    res.status(500).render('error', {
      title: '错误',
      message: '加载仪表板时发生错误',
      error
    });
  }
});

module.exports = router;