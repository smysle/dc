const { SlashCommandBuilder } = require('@discordjs/builders');
const { User } = require('../models');
const config = require('../config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('移除管理员')
    .setDescription('移除用户的管理员权限')
    .addUserOption(option => 
      option.setName('目标用户')
        .setDescription('要移除管理员权限的Discord用户')
        .setRequired(true)),
    
  async execute(interaction) {
    try {
      // 检查权限
      const member = interaction.member;
      const isSuperAdmin = member.roles.cache.some(role => 
        role.name === config.roles.superAdmin
      );
      
      if (!isSuperAdmin) {
        return interaction.reply({
          content: '您没有权限执行此命令，只有超级管理员可以移除管理员。',
          ephemeral: true
        });
      }
      
      // 获取参数
      const discordUser = interaction.options.getUser('目标用户');
      
      // 查找用户
      const user = await User.findOne({ discordId: discordUser.id });
      
      if (!user) {
        return interaction.reply({
          content: `找不到Discord用户 ${discordUser.tag} 的信息。`,
          ephemeral: true
        });
      }
      
      // 检查用户是否是管理员
      if (user.role !== 'admin') {
        return interaction.reply({
          content: `Discord用户 ${discordUser.tag} 不是管理员。`,
          ephemeral: true
        });
      }
      
      // 移除管理员权限
      user.role = 'user';
      
      // 保存用户
      await user.save();
      
      // 尝试移除Discord的管理员角色
      try {
        const guild = interaction.guild;
        const targetMember = await guild.members.fetch(discordUser.id);
        const adminRole = guild.roles.cache.find(role => role.name === config.roles.admin);
        
        if (adminRole && targetMember.roles.cache.has(adminRole.id)) {
          await targetMember.roles.remove(adminRole);
        }
      } catch (roleError) {
        console.warn('无法移除Discord管理员角色:', roleError);
      }
      
      // 回复
      await interaction.reply({
        content: `成功移除Discord用户 ${discordUser.tag} 的管理员权限。`,
        ephemeral: true
      });
      
    } catch (error) {
      console.error('移除管理员时出错:', error);
      await interaction.reply({
        content: '移除管理员时发生错误，请稍后再试。',
        ephemeral: true
      });
    }
  }
};