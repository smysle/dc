const { User } = require('../models');
const config = require('../config');
const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'myid',
  description: '查看你绑定的ID和配额信息',
  async execute(message, args) {
    try {
      // 查找用户记录
      const user = await User.findOne({ discordId: message.author.id });
      
      if (!user || !user.boundId) {
        return message.reply('你目前没有绑定任何ID。请联系管理员为你绑定ID。');
      }
      
      // 格式化配额信息
      const quota = user.quota || 0;
      const usedQuota = user.usedQuota || 0;
      const formattedQuota = `${quota.toLocaleString()} (${formatQuotaAsDollars(quota)})`;
      const formattedUsedQuota = `${usedQuota.toLocaleString()} (${formatQuotaAsDollars(usedQuota)})`;
      
      // 检查是否可以增加配额
      const minQuota = config.quota.minQuotaDollars * config.quota.dollarsToQuota;
      let canAddQuota = quota < minQuota;
      let cooldownInfo = '';
      
      if (canAddQuota && user.lastQuotaUpdate) {
        const now = new Date();
        const timeSinceLastUpdate = now.getTime() - user.lastQuotaUpdate.getTime();
        if (timeSinceLastUpdate < config.quota.updateCooldown) {
          canAddQuota = false;
          const timeLeft = config.quota.updateCooldown - timeSinceLastUpdate;
          const hoursLeft = Math.ceil(timeLeft / (1000 * 60 * 60));
          cooldownInfo = `冷却中: 还需等待 ${hoursLeft} 小时`;
        }
      }
      
      // 创建嵌入消息
      const embed = new EmbedBuilder()
        .setTitle('你的账户信息')
        .setColor('#0099ff')
        .setDescription(`以下是你的绑定ID和配额信息:`)
        .addFields(
          { name: '绑定ID', value: user.boundId, inline: true },
          { name: '当前配额', value: formattedQuota, inline: true },
          { name: '已使用配额', value: formattedUsedQuota, inline: true }
        );
      
      // 添加配额增加信息
      if (quota < minQuota) {
        if (canAddQuota) {
          embed.addFields({
            name: '配额状态',
            value: `你的配额低于 ${formatQuotaAsDollars(minQuota)}，可以使用 \`${config.prefix}addquota\` 命令增加配额。`
          });
        } else if (cooldownInfo) {
          embed.addFields({
            name: '配额状态',
            value: `你的配额低于 ${formatQuotaAsDollars(minQuota)}，但目前${cooldownInfo}。`
          });
        }
      }
      
      // 如果有绑定记录，添加相关信息
      if (user.boundAt) {
        const boundTime = new Date(user.boundAt).toLocaleString('zh-CN', {
          year: 'numeric',
          month: '2-digit',
          day: '2-digit',
          hour: '2-digit',
          minute: '2-digit'
        });
        
        embed.addFields({ name: '绑定时间', value: boundTime, inline: true });
      }
      
      // 发送私信
      message.author.send({ embeds: [embed] })
        .then(() => {
          // 如果在公共频道，只回复一个简单的确认
          if (message.channel.type !== 'DM') {
            message.reply('我已经通过私信发送了你的账户信息。');
          }
        })
        .catch(error => {
          console.error('发送私信失败:', error);
          message.reply('无法发送私信。请确保你已开启接收来自服务器成员的私信功能。');
        });
    } catch (error) {
      console.error('查询账户信息时出错:', error);
      message.reply('查询账户信息时发生错误，请稍后再试。');
    }
  }
};

// 格式化配额为美元
function formatQuotaAsDollars(quota) {
  return `$${(quota / config.quota.dollarsToQuota).toFixed(2)}`;
}