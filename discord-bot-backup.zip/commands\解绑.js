const { SlashCommandBuilder } = require('@discordjs/builders');
const { User } = require('../models');
const config = require('../config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('解绑')
    .setDescription('解除用户绑定')
    .addUserOption(option => 
      option.setName('目标用户')
        .setDescription('要解绑的Discord用户')
        .setRequired(true)),
    
  async execute(interaction) {
    try {
      // 检查权限
      const member = interaction.member;
      const hasPermission = member.roles.cache.some(role => 
        role.name === config.roles.admin || role.name === config.roles.superAdmin
      );
      
      if (!hasPermission) {
        return interaction.reply({
          content: '您没有权限执行此命令，只有管理员和超级管理员可以解除绑定。',
          ephemeral: true
        });
      }
      
      // 获取参数
      const discordUser = interaction.options.getUser('目标用户');
      
      // 查找用户
      const user = await User.findOne({ discordId: discordUser.id });
      
      if (!user || !user.boundId) {
        return interaction.reply({
          content: `Discord用户 ${discordUser.tag} 尚未绑定任何用户ID。`,
          ephemeral: true
        });
      }
      
      // 记录原始绑定ID用于回复
      const originalBoundId = user.boundId;
      
      // 解除绑定
      user.boundId = null;
      user.boundAt = null;
      
      // 保存用户
      await user.save();
      
      // 回复
      await interaction.reply({
        content: `成功解除用户ID ${originalBoundId} 与Discord用户 ${discordUser.tag} 的绑定。`,
        ephemeral: true
      });
      
    } catch (error) {
      console.error('解除绑定时出错:', error);
      await interaction.reply({
        content: '解除绑定时发生错误，请稍后再试。',
        ephemeral: true
      });
    }
  }
};