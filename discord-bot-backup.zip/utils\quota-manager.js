/**
 * 配额管理工具
 * 处理配额相关的业务逻辑
 */

const { User } = require('../models');
const config = require('../config');

/**
 * 检查并自动补充用户配额
 * 当用户余额低于100$时，自动增加200$
 * 
 * @param {string} userId - 用户ID
 * @param {Object} user - 用户对象（可选，如已有用户对象可传入避免重复查询）
 * @returns {Object} - 包含是否增加配额和更新后的用户对象
 */
async function checkAndRefillQuota(userId, user = null) {
  try {
    // 如果没有传入用户对象，则查询数据库
    if (!user) {
      // 使用lean()获取普通JS对象而不是Mongoose文档，避免任何默认值覆盖
      user = await User.findOne({ userId }).lean();
      if (!user) {
        return { success: false, message: '找不到用户', user: null, refilled: false };
      }
    }
    
    // 获取配额常量
    const minQuota = config.quota.minQuotaDollars * config.quota.dollarsToQuota; // 50,000,000
    const addQuota = config.quota.addQuotaDollars * config.quota.dollarsToQuota; // 100,000,000
    
    // 计算剩余配额(直接使用配额单位)
    const remainingQuota = user.quota - user.usedQuota;
    
    // 如果剩余配额低于阈值(50,000,000)，直接增加配额单位(100,000,000)
    if (remainingQuota < minQuota) {
      // 记录原始配额用于日志
      const originalQuota = user.quota;
      
      // 直接增加配额单位
      user.quota += addQuota;
      
      // 创建新的历史记录条目
      const historyEntry = {
        timestamp: new Date(),
        action: 'auto_refill',
        amount: addQuota,
        reason: `自动补充配额（余额低于$${config.quota.minQuotaDollars}）`,
        adminId: 'system'
      };
      
      // 使用findOneAndUpdate进行部分更新，只更新必要字段
      const updatedUser = await User.findOneAndUpdate(
        { userId },
        {
          $inc: { quota: addQuota },           // 增加配额
          $push: { quotaHistory: historyEntry },  // 添加历史记录
          $set: { lastQuotaUpdate: new Date() }   // 更新最后配额更新时间
        },
        { new: true, runValidators: true }     // 返回更新后的文档，运行验证器
      );
      
      // 将updatedUser赋值给user，以便返回更新后的用户对象
      user = updatedUser;
      
      // 创建辅助函数转换为美元格式
      const formatQuotaAsDollars = (quota) => `$${(quota / config.quota.dollarsToQuota).toFixed(2)}`;
      
      // 记录日志(同时显示原始配额和美元格式)
      console.log(`用户 ${userId} 配额自动补充: ${originalQuota} -> ${originalQuota + addQuota} (${formatQuotaAsDollars(originalQuota)} -> ${formatQuotaAsDollars(originalQuota + addQuota)})`);
      
      return {
        success: true,
        message: '配额已自动补充',
        user,
        refilled: true,
        amount: addQuota,
        amountInDollars: formatQuotaAsDollars(addQuota),
        previousQuota: originalQuota,
        previousQuotaInDollars: formatQuotaAsDollars(originalQuota),
        currentQuota: originalQuota + addQuota,
        currentQuotaInDollars: formatQuotaAsDollars(originalQuota + addQuota)
      };
    }
    
    // 配额足够，不需要补充
    return { success: true, message: '配额充足', user, refilled: false };
    
  } catch (error) {
    console.error('自动补充配额时出错:', error);
    return { success: false, message: error.message, user: null, refilled: false };
  }
}

/**
 * 更新用户已使用配额
 * 并检查是否需要自动补充配额
 * 
 * @param {string} userId - 用户ID
 * @param {number} amount - 使用的配额金额
 * @returns {Object} - 操作结果
 */
async function updateUsedQuota(userId, amount) {
  try {
    // 创建历史记录条目
    const historyEntry = {
      timestamp: new Date(),
      action: 'use',
      amount: amount,
      reason: '使用配额',
      adminId: 'system'
    };
    
    // 使用findOneAndUpdate进行部分更新，只更新必要字段
    const updatedUser = await User.findOneAndUpdate(
      { userId },
      {
        $inc: { usedQuota: amount },        // 增加已使用配额
        $push: { quotaHistory: historyEntry }  // 添加历史记录
      },
      { new: true, runValidators: true }    // 返回更新后的文档，运行验证器
    );
    
    if (!updatedUser) {
      return { success: false, message: '找不到用户' };
    }
    
    // 检查是否需要自动补充配额
    const refillResult = await checkAndRefillQuota(userId, updatedUser);
    
    return {
      success: true,
      message: '配额已更新',
      user: refillResult.user || updatedUser,
      refilled: refillResult.refilled,
      refillAmount: refillResult.refilled ? refillResult.amount : 0
    };
    
  } catch (error) {
    console.error('更新使用配额时出错:', error);
    return { success: false, message: error.message };
  }
}

module.exports = {
  checkAndRefillQuota,
  updateUsedQuota
};