# 本地测试指南

本文档提供在本地环境中快速部署和测试Discord用户管理与配额系统的步骤。

## 快速开始

### 1. 准备本地环境

#### 安装 MongoDB Community Edition

**Windows:**
1. 从[MongoDB官网](https://www.mongodb.com/try/download/community)下载安装包
2. 按照安装向导完成安装
3. MongoDB默认安装在`C:\Program Files\MongoDB\Server\<版本号>`
4. 创建数据目录：`mkdir C:\data\db`
5. 启动MongoDB服务：
   - 通过服务：在Windows服务中找到MongoDB并启动
   - 或通过命令行：`"C:\Program Files\MongoDB\Server\<版本号>\bin\mongod.exe" --dbpath="C:\data\db"`

**macOS (使用Homebrew):**
```bash
brew tap mongodb/brew
brew install mongodb-community
brew services start mongodb-community
```

#### 安装Node.js依赖
```bash
cd discord-bot
npm install --legacy-peer-deps
```

### 2. 配置Discord Bot

1. 访问[Discord开发者平台](https://discord.com/developers/applications)
2. 点击"New Application"创建新应用
3. 进入"Bot"选项卡，点击"Add Bot"
4. 在"TOKEN"部分，点击"Copy"复制Bot Token
5. 在"Bot Permissions"部分，选择以下权限：
   - Read Messages/View Channels
   - Send Messages
   - Manage Roles (如果您希望bot自动分配角色)
   - Read Message History
   - Use Slash Commands
6. 在"Privileged Gateway Intents"部分，启用：
   - SERVER MEMBERS INTENT
   - MESSAGE CONTENT INTENT
7. 保存更改

### 3. 邀请Bot到您的服务器

1. 在Discord开发者平台，进入您的应用
2. 转到"OAuth2 > URL Generator"
3. 在"SCOPES"中选择"bot"
4. 在"BOT PERMISSIONS"中选择相应权限
5. 复制生成的URL并在浏览器中打开
6. 选择要邀请Bot的服务器，点击"Authorize"

### 4. 创建Discord服务器角色

1. 在您的Discord服务器中，右键点击服务器名称，选择"Server Settings"
2. 点击"Roles"
3. 创建两个角色:
   - `super-admin` (用于超级管理员)
   - `admin` (用于普通管理员)
4. 将`super-admin`角色分配给您自己

### 5. 配置本地环境变量

编辑项目根目录下的`.env`文件：

```
# Discord Bot Token (从Discord开发者平台获取)
BOT_TOKEN=your_discord_bot_token

# MongoDB连接URI (本地测试)
MONGODB_URI=mongodb://localhost:27017/discord-bot

# Discord Bot设置
CLIENT_ID=your_application_client_id
GUILD_ID=your_discord_server_id

# Web服务器设置
PORT=3000
SESSION_SECRET=any-random-string-for-local-testing
```

### 6. 启动系统

```bash
# 启动MongoDB (如果尚未运行)
# Windows: 启动Windows服务或使用上面的mongod命令
# macOS/Linux: sudo service mongod start 或 brew services start mongodb-community

# 启动应用
node index.js
```

### 7. 测试功能

#### 访问Web界面
打开浏览器访问 `http://localhost:3000`
- 默认管理员账户: `admin`
- 默认密码: `admin`

#### 测试Discord命令
在您的Discord服务器中，发送以下命令测试Bot:
- `!help` - 显示可用命令列表
- `!ping` - 测试Bot是否正常响应

#### 测试ID绑定
1. 使用管理员权限在Discord中发送:
   ```
   !bind @用户名 测试ID
   ```
2. 被绑定的用户可以使用:
   ```
   !myid
   ```
   查看自己的ID和配额信息

#### 测试配额增加
1. 使用`!myid`命令查看当前配额
2. 当配额低于$100时，使用`!addquota`增加配额
3. 在Web界面中查看配额变化和排行榜

### 8. 故障排除

#### Bot不响应
- 检查`.env`文件中的BOT_TOKEN是否正确
- 检查Discord开发者平台中的Bot是否已启用
- 检查是否启用了必要的Intents
- 查看控制台日志是否有错误信息

#### Web界面无法访问
- 确保应用正在运行
- 检查控制台是否有错误信息
- 确认正在访问正确的端口(默认3000)

#### 数据库连接错误
- 确认MongoDB服务正在运行
- 检查MONGODB_URI是否正确
- 尝试使用MongoDB Compass测试连接

#### 绑定ID失败
- 确认您有管理员或超级管理员角色
- 确认命令格式正确: `!bind @用户名 ID`
- 检查Bot是否有足够的权限

### 9. 测试后清理

如果您想清除测试数据，可以重置MongoDB数据库:
```bash
mongo
> use discord-bot
> db.dropDatabase()
> exit
```

或者仅清除用户数据:
```bash
mongo
> use discord-bot
> db.users.drop()
> exit